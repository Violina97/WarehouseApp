using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using WarehouseApp.Data;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace WarehouseApp.Pages
{
    [AllowAnonymous] 
    public class LoginModel : PageModel
    {
        private readonly WarehouseContext _context;

        public LoginModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = _context.Users
                .Include(u => u.Worker)
                .FirstOrDefault(u => u.Username == Username);

            if (user == null)
            {
                ModelState.AddModelError("", "Грешно потребителско име или парола");
                return Page();
            }

            bool isPasswordValid =
                BCrypt.Net.BCrypt.Verify(
                    Password,
                    user.Password);

            if (!isPasswordValid)
            {
                ModelState.AddModelError("", "Грешно потребителско име или парола");
                return Page();
            }

            var claims = new List<Claim>
    {
        new Claim(ClaimTypes.Name, user.Username),
        new Claim(ClaimTypes.Role, user.Role),
        new Claim("UserId", user.Id.ToString())
    };

            if (user.WorkerId.HasValue)
            {
                claims.Add(
                    new Claim(
                        "WorkerId",
                        user.WorkerId.Value.ToString()));
            }

            var identity =
                new ClaimsIdentity(claims, "CookieAuth");

            var principal =
                new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(
                "CookieAuth",
                principal);

            return RedirectToPage("/Dashboard");
        }
    }
}