﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ContactPersons
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public ContactPerson ContactPerson { get; set; } = new();

      
        public async Task<IActionResult> OnGetAsync(int id)
        {
            ContactPerson = await _context.ContactPersons
                .Include(x => x.Position)
                .Include(x => x.Client)
                .FirstOrDefaultAsync(x => x.ContactPersonId == id);

            if (ContactPerson == null)
                return NotFound();

            return Page();
        }

     
        public async Task<IActionResult> OnPostAsync(int id)
        {
            var entity = await _context.ContactPersons.FindAsync(id);

            if (entity != null)
            {
                _context.ContactPersons.Remove(entity);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("Index");
        }
    }
}