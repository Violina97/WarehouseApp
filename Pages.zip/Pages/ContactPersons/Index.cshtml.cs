﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ContactPersons
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public List<ContactPerson> ContactPersons { get; set; } = new();

        
        public async Task OnGetAsync()
        {
            ContactPersons = await _context.ContactPersons
                .Include(x => x.Position)
                .Include(x => x.Client)
                .ToListAsync();
        }
    }
}