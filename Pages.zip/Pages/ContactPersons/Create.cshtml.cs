﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ContactPersons
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public ContactPerson ContactPerson { get; set; } = new();

        public List<SelectListItem> Positions { get; set; } = new();
        public List<SelectListItem> Clients { get; set; } = new();

       
        public async Task OnGetAsync()
        {
            Positions = await _context.Positions
                .Select(p => new SelectListItem
                {
                    Value = p.PositionId.ToString(),
                    Text = p.PositionName
                }).ToListAsync();

            Clients = await _context.Clients
                .Select(c => new SelectListItem
                {
                    Value = c.ClientId.ToString(),
                    Text = c.Name
                }).ToListAsync();
        }

      
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            _context.ContactPersons.Add(ContactPerson);
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}