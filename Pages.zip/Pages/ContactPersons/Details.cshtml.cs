﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ContactPersons
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

      
        public ContactPerson ContactPerson { get; set; } = new();

        
        public async Task<IActionResult> OnGetAsync(int id)
        {
            ContactPerson = await _context.ContactPersons
                .Include(x => x.Position)
                .Include(x => x.Client)
                .FirstOrDefaultAsync(x => x.ContactPersonId == id);

            if (ContactPerson == null)
                return NotFound();

            return Page();
        }
    }
}