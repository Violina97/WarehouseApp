﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ContactPersons
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public ContactPerson ContactPerson { get; set; } = new();

        public List<SelectListItem> Positions { get; set; } = new();
        public List<SelectListItem> Clients { get; set; } = new();

     
        public async Task<IActionResult> OnGetAsync(int id)
        {
            ContactPerson = await _context.ContactPersons.FindAsync(id);

            if (ContactPerson == null)
                return NotFound();

            
            Positions = await _context.Positions
                .Select(p => new SelectListItem
                {
                    Value = p.PositionId.ToString(),
                    Text = p.PositionName
                }).ToListAsync();

        
            Clients = await _context.Clients
                .Select(c => new SelectListItem
                {
                    Value = c.ClientId.ToString(),
                    Text = c.Name
                }).ToListAsync();

            return Page();
        }

        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            _context.Attach(ContactPerson).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}