﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Cities
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public City City { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            City = await _context.Cities
                .Include(c => c.Municipality)
                .FirstOrDefaultAsync(c => c.CityId == id);

            if (City == null)
                return NotFound();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var entity = await _context.Cities.FindAsync(id);

            if (entity != null)
            {
                _context.Cities.Remove(entity);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("Index");
        }
    }
}