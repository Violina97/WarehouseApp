﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Cities
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public City City { get; set; } = new();

        public List<SelectListItem> Municipalities { get; set; } = new();

        public async Task OnGetAsync()
        {
            Municipalities = await _context.Municipalities
                .Select(m => new SelectListItem
                {
                    Value = m.Id.ToString(),
                    Text = m.MunicipName
                })
                .ToListAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            _context.Cities.Add(City);
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}