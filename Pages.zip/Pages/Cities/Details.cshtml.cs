﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Cities
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public City City { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            City = await _context.Cities
                .Include(c => c.Municipality)
                .ThenInclude(m => m.Region)
                .FirstOrDefaultAsync(c => c.CityId == id);

            if (City == null)
                return NotFound();

            return Page();
        }
    }
}