﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ClientStores
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public ClientStore ClientStore { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            
            ClientStore = await _context.ClientStores
                .Include(x => x.City)
                .Include(x => x.Client)
                .FirstOrDefaultAsync(x => x.ClientStoreId == id);

            if (ClientStore == null)
                return NotFound();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            
            var entity = await _context.ClientStores
                .FindAsync(id);

            if (entity != null)
            {
                _context.ClientStores.Remove(entity);

                await _context.SaveChangesAsync();
            }

            return RedirectToPage("Index");
        }
    }
}