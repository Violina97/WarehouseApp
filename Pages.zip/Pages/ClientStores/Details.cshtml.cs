﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ClientStores
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public ClientStore ClientStore { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            ClientStore = await _context.ClientStores
                .Include(x => x.City)
                .Include(x => x.Client)
                .FirstOrDefaultAsync(x => x.ClientStoreId == id);

            if (ClientStore == null)
                return NotFound();

            return Page();
        }
    }
}