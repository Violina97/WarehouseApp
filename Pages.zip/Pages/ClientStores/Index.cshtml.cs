﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.ClientStores
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

      
        public List<ClientStore> ClientStores { get; set; } = new();

        public async Task OnGetAsync()
        {
            ClientStores = await _context.ClientStores
                .Include(x => x.City)
                .Include(x => x.Client)
                .ToListAsync();
        }
    }
}