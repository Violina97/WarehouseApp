﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrdersDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public OutgoingOrder? Order { get; set; }

        public List<OutgoingOrderDetail> Details { get; set; } = new();

        public decimal Total { get; set; }

        public decimal TotalQuantity { get; set; }

        public async Task<IActionResult> OnGetAsync(int outgoingOrderId)
        {
            Order = await _context.OutgoingOrders
                .AsNoTracking()
                .Include(o => o.ClientStore)
                .Include(o => o.Store)
                .FirstOrDefaultAsync(o => o.Id == outgoingOrderId);

            if (Order == null)
                return NotFound();

            Details = await _context.OutgoingOrderDetails
                .AsNoTracking()
                .Include(d => d.Product)
                .Where(d => d.OutgoingOrderId == outgoingOrderId)
                .ToListAsync();

            TotalQuantity = Details.Sum(x => x.Quantity);

            Total = Details.Sum(x =>
                x.Quantity * (x.Product?.Price ?? 0));

            return Page();
        }
    }
}