﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrdersDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public OutgoingOrderDetail OutgoingOrderDetail { get; set; } = new();

        public SelectList ProductsSelectList { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var item = await _context.OutgoingOrderDetails
                .AsNoTracking()
                .Include(x => x.Product)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (item == null)
                return NotFound();

            OutgoingOrderDetail = item;

            await LoadSelectLists();

            return Page();
        }


        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await LoadSelectLists();
                return Page();
            }

            var existing = await _context.OutgoingOrderDetails
                .FirstOrDefaultAsync(x => x.Id == OutgoingOrderDetail.Id);

            if (existing == null)
                return NotFound();

            if (OutgoingOrderDetail.ProductId <= 0)
            {
                ModelState.AddModelError("", "Моля изберете продукт.");

                await LoadSelectLists();
                return Page();
            }

            if (OutgoingOrderDetail.Quantity <= 0)
            {
                ModelState.AddModelError("",
                    "Количеството трябва да бъде по-голямо от 0.");

                await LoadSelectLists();
                return Page();
            }

            var productExists = await _context.Products
                .AnyAsync(x => x.Id == OutgoingOrderDetail.ProductId);

            if (!productExists)
            {
                ModelState.AddModelError("", "Продуктът не съществува.");

                await LoadSelectLists();
                return Page();
            }

            
            var duplicateExists = await _context.OutgoingOrderDetails
                .AnyAsync(x =>
                    x.OutgoingOrderId == existing.OutgoingOrderId &&
                    x.ProductId == OutgoingOrderDetail.ProductId &&
                    x.Id != OutgoingOrderDetail.Id);

            if (duplicateExists)
            {
                ModelState.AddModelError("",
                    "Този продукт вече съществува в поръчката.");

                await LoadSelectLists();
                return Page();
            }

            var deliveredQuantity = await _context.DeliveryDetails
                .Where(x => x.ProductId == OutgoingOrderDetail.ProductId)
                .SumAsync(x => (decimal?)x.Quantity) ?? 0;

            var orderedQuantity = await _context.OutgoingOrderDetails
                .Where(x =>
                    x.ProductId == OutgoingOrderDetail.ProductId &&
                    x.Id != OutgoingOrderDetail.Id)
                .SumAsync(x => (decimal?)x.Quantity) ?? 0;

            var availableQuantity =
                deliveredQuantity - orderedQuantity;

            if (OutgoingOrderDetail.Quantity > availableQuantity)
            {
                ModelState.AddModelError("",
                    $"Недостатъчна наличност. Налични: {availableQuantity}");

                await LoadSelectLists();
                return Page();
            }

            
            existing.ProductId = OutgoingOrderDetail.ProductId;

            existing.Quantity = OutgoingOrderDetail.Quantity;

            await _context.SaveChangesAsync();

            return RedirectToPage(
                "/OutgoingOrderDetails/Create",
                new
                {
                    outgoingOrderId = existing.OutgoingOrderId
                });
        }

    
        private async Task LoadSelectLists()
        {
            ProductsSelectList = new SelectList(
                await _context.Products
                    .AsNoTracking()
                    .OrderBy(x => x.Name)
                    .ToListAsync(),
                "Id",
                "Name");
        }
    }
}