﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrdersDetails
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public OutgoingOrderDetail OutgoingOrderDetail { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (id <= 0)
                return NotFound();

            var item = await _context.OutgoingOrderDetails
                .AsNoTracking()
                .Include(x => x.Product)
                .Include(x => x.OutgoingOrder)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (item == null)
                return NotFound();

            OutgoingOrderDetail = item;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var item = await _context.OutgoingOrderDetails
                .FirstOrDefaultAsync(x => x.Id == id);

            if (item == null)
                return NotFound();

            var orderId = item.OutgoingOrderId;

            _context.OutgoingOrderDetails.Remove(item);

            await _context.SaveChangesAsync();

            TempData["Success"] = "Редът е изтрит успешно.";

            return RedirectToPage("/OutgoingOrderDetails/Create", new
            {
                outgoingOrderId = orderId
            });
        }
    }
}