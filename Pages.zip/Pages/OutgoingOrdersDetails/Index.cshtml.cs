﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.OutgoingOrdersDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public int OutgoingOrderId { get; set; }

        public List<OutgoingOrderDetailVm> Items { get; set; } = new();

   
        public string OrderNumber { get; set; } = "";
        public string ClientName { get; set; } = "";
        public string StoreName { get; set; } = "";

        public decimal TotalQuantity { get; set; }
        public decimal TotalAmount { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (OutgoingOrderId <= 0)
                return BadRequest();

            var order = await _context.OutgoingOrders
                .AsNoTracking()
                .Include(x => x.ClientStore)
                .Include(x => x.Store)
                .FirstOrDefaultAsync(x => x.Id == OutgoingOrderId);

            if (order == null)
                return NotFound();

            OrderNumber = order.Number?.ToString() ?? "-";
            ClientName = order.ClientStore?.Name ?? "-";
            StoreName = order.Store?.Name ?? "-";

            Items = await _context.OutgoingOrderDetails
                .AsNoTracking()
                .Where(x => x.OutgoingOrderId == OutgoingOrderId)
                .Select(x => new OutgoingOrderDetailVm
                {
                    Id = x.Id,
                    ProductName = x.Product!.Name,
                    Quantity = x.Quantity,
                    UnitPrice = x.Product.Price
                })
                .ToListAsync();

            TotalQuantity = Items.Sum(x => x.Quantity);
            TotalAmount = Items.Sum(x => x.Total);

            return Page();
        }
    }

   
    public class OutgoingOrderDetailVm
    {
        public int Id { get; set; }

        public string ProductName { get; set; } = "";

        public decimal Quantity { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal Total => Quantity * UnitPrice;
    }
}