﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrdersDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public int OutgoingOrderId { get; set; }

        [BindProperty]
        public OutgoingOrderDetail Input { get; set; } = new();

        public List<OutgoingOrderDetail> DetailsList { get; set; } = new();

        public SelectList Products { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int outgoingOrderId)
        {
            OutgoingOrderId = outgoingOrderId;

            var exists = await _context.OutgoingOrders
                .AnyAsync(x => x.Id == outgoingOrderId);

            if (!exists)
                return NotFound();

            await LoadData();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (OutgoingOrderId <= 0)
                return BadRequest();

            Input.OutgoingOrderId = OutgoingOrderId;

            await LoadData();

            if (!ModelState.IsValid)
                return Page();

            if (Input.ProductId <= 0 || Input.Quantity <= 0)
            {
                ModelState.AddModelError("", "Невалидни данни.");
                return Page();
            }

            var order = await _context.OutgoingOrders
                .FirstOrDefaultAsync(x => x.Id == OutgoingOrderId);

            if (order == null)
                return NotFound();


            var deliveredQuantity = await _context.DeliveryDetails
              .Where(x =>
              x.ProductId == Input.ProductId &&
              x.DeliveryMaster != null &&
              x.DeliveryMaster.StoreId == order.StoreId)
             .SumAsync(x => (decimal?)x.Quantity) ?? 0;

         
            var orderedQuantity = await _context.OutgoingOrderDetails
                .Where(x =>
                    x.ProductId == Input.ProductId &&
                    x.OutgoingOrder.StoreId == order.StoreId)
                .SumAsync(x => (decimal?)x.Quantity) ?? 0;

           
            var available = deliveredQuantity - orderedQuantity;

            if (available < Input.Quantity)
            {
                ModelState.AddModelError("", $"Недостатъчна наличност. Свободни: {available}");
                await LoadData();
                return Page();
            }


            System.Diagnostics.Debug.WriteLine(
                $"Product {Input.ProductId} | Available: {available} | Requested: {Input.Quantity}");

         
            var existing = await _context.OutgoingOrderDetails
                .FirstOrDefaultAsync(x =>
                    x.OutgoingOrderId == OutgoingOrderId &&
                    x.ProductId == Input.ProductId);

            if (existing != null)
            {
                existing.Quantity += Input.Quantity;
            }
            else
            {
                _context.OutgoingOrderDetails.Add(new OutgoingOrderDetail
                {
                    OutgoingOrderId = OutgoingOrderId,
                    ProductId = Input.ProductId,
                    Quantity = Input.Quantity
                });
            }

            await _context.SaveChangesAsync();

            return RedirectToPage("./Create", new { outgoingOrderId = OutgoingOrderId });
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id, int outgoingOrderId)
        {
            var item = await _context.OutgoingOrderDetails
                .FirstOrDefaultAsync(x =>
                    x.Id == id &&
                    x.OutgoingOrderId == outgoingOrderId);

            if (item != null)
            {
                _context.OutgoingOrderDetails.Remove(item);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Create", new { outgoingOrderId });
        }

        private async Task LoadData()
        {
            Products = new SelectList(
                await _context.Products
                    .AsNoTracking()
                    .OrderBy(x => x.Name)
                    .ToListAsync(),
                "Id",
                "Name");

            DetailsList = await _context.OutgoingOrderDetails
                .AsNoTracking()
                .Include(x => x.Product)
                .Where(x => x.OutgoingOrderId == OutgoingOrderId)
                .ToListAsync();
        }
    }
}