﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Regions
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Region Region { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Region = await _context.Regions.FindAsync(id);

            if (Region == null)
                return NotFound();

            return Page();
        }
    }
}