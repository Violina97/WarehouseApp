﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Regions
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

   
        public List<Region> Regions { get; set; } = new();

        public async Task OnGetAsync()
        {
            Regions = await _context.Regions.ToListAsync();
        }
    }
}