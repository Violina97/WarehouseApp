﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Regions
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Region Region { get; set; } = new();

       
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            _context.Regions.Add(Region);
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}