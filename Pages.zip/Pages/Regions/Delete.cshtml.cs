﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Regions
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public Region Region { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Region = await _context.Regions.FindAsync(id);

            if (Region == null)
                return NotFound();

            return Page();
        }

        
        public async Task<IActionResult> OnPostAsync(int id)
        {
            var entity = await _context.Regions.FindAsync(id);

            if (entity != null)
            {
                _context.Regions.Remove(entity);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("Index");
        }
    }
}