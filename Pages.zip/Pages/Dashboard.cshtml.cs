using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages
{
    [Authorize(Roles = "Admin,Employee")]
    public class DashboardModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DashboardModel(WarehouseContext context)
        {
            _context = context;
        }

        // ================= KPI =================
        public int ProductsCount { get; set; }
        public int ClientsCount { get; set; }
        public int OrdersCount { get; set; }
        public int StoresCount { get; set; }

        // ================= RECENT ORDERS =================
        public List<OutgoingOrder> RecentOrders { get; set; } = new();

        // ================= LOW STOCK =================
        public class ProductStockView
        {
            public int ProductId { get; set; }
            public string Name { get; set; } = "";

            public decimal Stock { get; set; }
            public decimal Reserved { get; set; }
            public decimal Free { get; set; }
        }

        public List<ProductStockView> LowStockProducts { get; set; } = new();

        public void OnGet()
        {
            // KPI
            ProductsCount = _context.Products.Count();
            ClientsCount = _context.ClientStores.Count();
            OrdersCount = _context.OutgoingOrders.Count();
            StoresCount = _context.Stores.Count();

            // Recent orders
            RecentOrders = _context.OutgoingOrders
                .Include(o => o.Store)
                .Include(o => o.ClientStore)
                .OrderByDescending(o => o.Date)
                .Take(5)
                .ToList();

            // Stock
            LowStockProducts = _context.Products
                .Select(p => new ProductStockView
                {
                    ProductId = p.Id,
                    Name = p.Name,

                    Stock =
                        (_context.DeliveryDetails
                            .Where(d => d.ProductId == p.Id)
                            .Sum(d => (decimal?)d.Quantity) ?? 0),

                    Reserved =
                        (_context.OutgoingOrderDetails
                            .Where(o => o.ProductId == p.Id)
                            .Sum(o => (decimal?)o.Quantity) ?? 0)
                })
                .ToList();

            foreach (var item in LowStockProducts)
            {
                item.Free = item.Stock - item.Reserved;

                if (item.Free < 0)
                    item.Free = 0;
            }

            LowStockProducts = LowStockProducts
                .Where(x => x.Free <= 5)
                .OrderBy(x => x.Free)
                .ToList();
        }
    }
}