﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Measures
{
    [Authorize(Roles = "Admin")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Measure Measure { get; set; } = new();

      
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Measure = await _context.Measures.FindAsync(id);

            if (Measure == null)
                return NotFound();

            return Page();
        }

     
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            _context.Attach(Measure).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}