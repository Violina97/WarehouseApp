﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Measures
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public List<Measure> Measures { get; set; } = new();

      
        public async Task OnGetAsync()
        {
            Measures = await _context.Measures.ToListAsync();
        }
    }
}