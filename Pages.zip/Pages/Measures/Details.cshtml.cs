﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Measures
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Measure Measure { get; set; } = new();

  
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Measure = await _context.Measures.FindAsync(id);

            if (Measure == null)
                return NotFound();

            return Page();
        }
    }
}