﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Measures
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Measure Measure { get; set; } = new();

   
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Measure = await _context.Measures.FindAsync(id);

            if (Measure == null)
                return NotFound();

            return Page();
        }


        public async Task<IActionResult> OnPostAsync()
        {
            var entity = await _context.Measures.FindAsync(Measure.MeasureId);

            if (entity != null)
            {
                _context.Measures.Remove(entity);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("Index");
        }
    }
}