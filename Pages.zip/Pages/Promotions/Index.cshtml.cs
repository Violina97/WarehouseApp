﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Promotions
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public IList<Promotion> Promotions { get; set; } = new List<Promotion>();

        public async Task OnGetAsync()
        {
            Promotions = await _context.Promotions
                .Include(p => p.Store)
                .Include(p => p.Product)
                .OrderByDescending(p => p.Validity)
                .ToListAsync();
        }
    }
}