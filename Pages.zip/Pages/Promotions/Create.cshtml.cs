﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Promotions
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Promotion Promotion { get; set; } = new Promotion();

        public SelectList StoreList { get; set; } = default!;
        public SelectList ProductList { get; set; } = default!;

        public async Task OnGetAsync()
        {
            await LoadDataAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await LoadDataAsync();
                return Page();
            }

  
            if (Promotion.Validity < DateTime.Today)
            {
                ModelState.AddModelError(string.Empty,
                    "Моля, посочете валидна дата.");

                await LoadDataAsync();
                return Page();
            }

            bool exists = await _context.Promotions.AnyAsync(p =>
                p.StoreId == Promotion.StoreId &&
                p.ProductId == Promotion.ProductId &&
                p.Validity >= DateTime.Today);

            if (exists)
            {
                ModelState.AddModelError(string.Empty,
                    "Вече съществува активна промоция за този продукт в избрания склад.");

                await LoadDataAsync();
                return Page();
            }

            _context.Promotions.Add(Promotion);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadDataAsync()
        {
            var stores = await _context.Stores
                .OrderBy(s => s.Name)
                .ToListAsync();

            var products = await _context.Products
                .OrderBy(p => p.Name)
                .ToListAsync();

            StoreList = new SelectList(stores, "Id", "Name");
            ProductList = new SelectList(products, "Id", "Name");
        }
    }
}