﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public DeliveryMaster DeliveryMaster { get; set; } = new();

        public SelectList Stores { get; set; } = default!;

        public SelectList Clients { get; set; } = default!;

        public SelectList Workers { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var item = await _context.DeliveryMasters
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.DeliveryMId == id);

            if (item == null)
                return NotFound();

            DeliveryMaster = item;

            LoadData();

            return Page();
        }

        private void LoadData()
        {
            Stores = new SelectList(
                _context.Stores
                    .AsNoTracking()
                    .OrderBy(x => x.Name)
                    .Select(x => new
                    {
                        x.Id,
                        x.Name
                    })
                    .ToList(),
                "Id",
                "Name"
            );

            Clients = new SelectList(
                _context.ClientStores
                    .AsNoTracking()
                    .OrderBy(x => x.Name)
                    .Select(x => new
                    {
                        x.ClientStoreId,
                        x.Name
                    })
                    .ToList(),
                "ClientStoreId",
                "Name"
            );

            Workers = new SelectList(
                _context.Workers
                    .AsNoTracking()
                    .OrderBy(x => x.FirstName)
                    .ThenBy(x => x.LastName)
                    .Select(x => new
                    {
                        x.WorkerId,

                        FullName =
                            (x.FirstName ?? "")
                            + " "
                            + (x.LastName ?? "")
                    })
                    .ToList(),
                "WorkerId",
                "FullName"
            );
        }

        public async Task<IActionResult> OnPostAsync()
        {
            LoadData();

            if (!ModelState.IsValid)
                return Page();

            // validation
            if (DeliveryMaster.StoreId <= 0)
            {
                ModelState.AddModelError("",
                    "Моля изберете склад.");

                return Page();
            }

            if (DeliveryMaster.ClientStoreId <= 0)
            {
                ModelState.AddModelError("",
                    "Моля изберете контрагент.");

                return Page();
            }

            if (DeliveryMaster.WorkerId <= 0)
            {
                ModelState.AddModelError("",
                    "Моля изберете служител.");

                return Page();
            }

            var item = await _context.DeliveryMasters
                .FirstOrDefaultAsync(x =>
                    x.DeliveryMId == DeliveryMaster.DeliveryMId);

            if (item == null)
                return NotFound();

       
            item.Number = DeliveryMaster.Number;

            item.DeliveryDate = DeliveryMaster.DeliveryDate;

            item.StoreId = DeliveryMaster.StoreId;

            item.ClientStoreId = DeliveryMaster.ClientStoreId;

            item.WorkerId = DeliveryMaster.WorkerId;

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}