﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryMasters
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public DeliveryMaster DeliveryMaster { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (id <= 0)
                return NotFound();

            DeliveryMaster = await _context.DeliveryMasters
                .AsNoTracking()
                .Include(d => d.Store)
                .Include(d => d.ClientStore)
                .Include(d => d.Worker)
                .FirstOrDefaultAsync(d => d.DeliveryMId == id);

            if (DeliveryMaster == null)
                return NotFound();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            if (id <= 0)
                return NotFound();

            var delivery = await _context.DeliveryMasters
                .Include(d => d.DeliveryDetails)
                .FirstOrDefaultAsync(d => d.DeliveryMId == id);

            if (delivery == null)
                return NotFound();

           
            _context.DeliveryMasters.Remove(delivery);

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}