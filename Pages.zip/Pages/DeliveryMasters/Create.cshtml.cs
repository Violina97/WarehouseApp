﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public DeliveryMaster DeliveryMaster { get; set; } = new();

       

        public SelectList Stores { get; set; }
        public SelectList Clients { get; set; }
        public SelectList Workers { get; set; }
        

        public void OnGet()
        {
            LoadData();

            DeliveryMaster = new DeliveryMaster
            {
                DeliveryDate = DateTime.Today
            };
        }

        private void LoadData()
        {
            Stores = new SelectList(
    _context.Stores
        .AsNoTracking()
        .Where(x => x.Id > 0)
        .Select(x => new { x.Id, x.Name })
        .ToList(),
    "Id",
    "Name"
);

            Clients = new SelectList(
    _context.ClientStores
        .AsNoTracking()
        .Where(x => x.ClientStoreId > 0)
        .Select(x => new { x.ClientStoreId, x.Name })
        .ToList(),
    "ClientStoreId",
    "Name"
);
            Workers = new SelectList(
    _context.Workers
        .AsNoTracking()
        .Where(x => x.WorkerId > 0)
        .Select(x => new
        {
            x.WorkerId,
            FullName = (x.FirstName ?? "") + " " + (x.LastName ?? "")
        })
        .ToList(),
    "WorkerId",
    "FullName"
);
         
        }

        public async Task<IActionResult> OnPostAsync()
        {
            LoadData();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.DeliveryMasters.Add(DeliveryMaster);
            await _context.SaveChangesAsync();

            DeliveryMaster.Number = DeliveryMaster.DeliveryMId;

            _context.DeliveryMasters.Update(DeliveryMaster);
            await _context.SaveChangesAsync();

            return RedirectToPage("/DeliveryDetails/Create",
                new { deliveryMId = DeliveryMaster.DeliveryMId });
        }
    }
    
}