﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public DeliveryMaster? DeliveryMaster { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (id <= 0)
                return BadRequest();

            DeliveryMaster = await _context.DeliveryMasters
                .AsNoTracking()
                .Include(d => d.Store)
                .Include(d => d.ClientStore)
                .Include(d => d.Worker)
                .Include(d => d.DeliveryDetails)
                    .ThenInclude(dd => dd.Product)
                        .ThenInclude(p => p.Measure)
                .FirstOrDefaultAsync(d => d.DeliveryMId == id);

            if (DeliveryMaster == null)
                return NotFound();

            return Page();
        }
    }
}