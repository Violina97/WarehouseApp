﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.DeliveryMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public List<DeliveryMasterVm> DeliveryMasters { get; set; } = new();

        public async Task OnGetAsync()
        {
            var query = await _context.DeliveryMasters
                .AsNoTracking()
                .Select(d => new DeliveryMasterVm
                {
                    DeliveryMId = d.DeliveryMId,
                    Number = d.Number,
                    DeliveryDate = d.DeliveryDate,

                    StoreName = d.Store != null ? d.Store.Name : "-",
                    ClientName = d.ClientStore != null ? d.ClientStore.Name : "-",
                    WorkerName = d.Worker != null
                        ? d.Worker.FirstName + " " + d.Worker.LastName
                        : "-",

                    TotalAmount = d.DeliveryDetails
                        .Sum(x => (decimal?)x.Quantity * x.Price) ?? 0,

                    ItemsCount = d.DeliveryDetails.Count()
                })
                .OrderByDescending(x => x.DeliveryDate)
                .ThenByDescending(x => x.Number)
                .ToListAsync();

            DeliveryMasters = query;
        }
    }

    public class DeliveryMasterVm
    {
        public int DeliveryMId { get; set; }

        public int Number { get; set; }

        public DateTime DeliveryDate { get; set; }

        public string StoreName { get; set; } = "";

        public string ClientName { get; set; } = "";

        public string WorkerName { get; set; } = "";

        public decimal TotalAmount { get; set; }

        public int ItemsCount { get; set; }
    }
}