﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.AutomobileBrands
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public AutomobileBrand AutomobileBrand { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AutomobileBrand = await _context.AutomobileBrands.FindAsync(id);

            if (AutomobileBrand == null)
                return NotFound();

            return Page();
        }

     
        public async Task<IActionResult> OnPostAsync(int id)
        {
            var item = await _context.AutomobileBrands.FindAsync(id);

            if (item != null)
            {
                _context.AutomobileBrands.Remove(item);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}