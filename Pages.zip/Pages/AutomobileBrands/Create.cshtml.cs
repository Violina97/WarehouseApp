﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.AutomobileBrands
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public AutomobileBrand AutomobileBrand { get; set; }

        public IActionResult OnGet()
        {
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            _context.AutomobileBrands.Add(AutomobileBrand);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}