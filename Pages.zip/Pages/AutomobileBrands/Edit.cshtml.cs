﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.AutomobileBrands
{
    [Authorize(Roles = "Admin")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public AutomobileBrand AutomobileBrand { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AutomobileBrand = await _context.AutomobileBrands.FindAsync(id);

            if (AutomobileBrand == null)
                return NotFound();

            return Page();
        }

      
        public async Task<IActionResult> OnPostAsync()
        {
            _context.Attach(AutomobileBrand).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}