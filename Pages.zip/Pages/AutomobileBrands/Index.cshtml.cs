﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.AutomobileBrands
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public IList<AutomobileBrand> AutomobileBrands { get; set; }

        public async Task OnGetAsync()
        {
            AutomobileBrands = await _context.AutomobileBrands.ToListAsync();
        }
    }
}