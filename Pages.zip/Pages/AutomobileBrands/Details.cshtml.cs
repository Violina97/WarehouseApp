﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.AutomobileBrands
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public AutomobileBrand AutomobileBrand { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            AutomobileBrand = await _context.AutomobileBrands
                .FirstOrDefaultAsync(m => m.Id == id);

            if (AutomobileBrand == null)
                return NotFound();

            return Page();
        }
    }
}