﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrders
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public OutgoingOrder Order { get; set; } = new();

        public decimal TotalQuantity { get; set; }
        public decimal GrandTotal { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Order = await _context.OutgoingOrders
                .AsNoTracking()
                .Include(o => o.ClientStore)
                .Include(o => o.Store)
                .Include(o => o.OutgoingOrderDetails)
                    .ThenInclude(d => d.Product)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (Order == null)
                return NotFound();

            TotalQuantity = Order.OutgoingOrderDetails
                .Sum(x => x.Quantity);

            GrandTotal = Order.OutgoingOrderDetails
                .Sum(x =>
                    (x.Product != null ? x.Product.Price : 0m)
                    * x.Quantity);

            return Page();
        }
    }
}