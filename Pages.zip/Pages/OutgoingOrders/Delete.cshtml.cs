﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrders
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public OutgoingOrder Order { get; set; } = new();

        public decimal TotalQuantity { get; set; }
        public decimal GrandTotal { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Order = await _context.OutgoingOrders
                .AsNoTracking()
                .Include(x => x.ClientStore)
                .Include(x => x.Store)
                .Include(x => x.OutgoingOrderDetails)
                    .ThenInclude(x => x.Product)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (Order == null)
                return NotFound();

            TotalQuantity = Order.OutgoingOrderDetails.Sum(x => x.Quantity);

            GrandTotal = Order.OutgoingOrderDetails.Sum(x =>
                (x.Product?.Price ?? 0m) * x.Quantity);

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var order = await _context.OutgoingOrders
                .Include(x => x.OutgoingOrderDetails)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (order == null)
                return NotFound();

            try
            {
               
                _context.OutgoingOrderDetails.RemoveRange(order.OutgoingOrderDetails);

               
                _context.OutgoingOrders.Remove(order);

                await _context.SaveChangesAsync();
            }
            catch
            {
                TempData["Error"] = "Грешка при изтриване на поръчката.";
                return RedirectToPage("./Details", new { id });
            }

            TempData["Success"] = "Поръчката е изтрита успешно.";

            return RedirectToPage("./Index");
        }
    }
}