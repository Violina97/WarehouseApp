﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.OutgoingOrders
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public List<OutgoingOrderVm> Orders { get; set; } = new();

        public async Task OnGetAsync()
        {
            Orders = await _context.OutgoingOrders
                .AsNoTracking()
                .Select(o => new OutgoingOrderVm
                {
                    Id = o.Id,
                    Number = o.Number,
                    Date = o.Date,

                    ClientName = o.ClientStore != null ? o.ClientStore.Name : "",
                    StoreName = o.Store != null ? o.Store.Name : "",

                    ItemsCount = o.OutgoingOrderDetails.Count(),

                    TotalAmount =
                        o.OutgoingOrderDetails
                            .Sum(d =>
                                d.Quantity *
                                (d.Product != null ? d.Product.Price : 0m)
                            )
                })
                .OrderByDescending(x => x.Date)
                .ToListAsync();
        }
    }

    public class OutgoingOrderVm
    {
        public int Id { get; set; }
        public int? Number { get; set; }
        public DateTime Date { get; set; }

        public string ClientName { get; set; } = "";
        public string StoreName { get; set; } = "";

        public int ItemsCount { get; set; }
        public decimal TotalAmount { get; set; }

        public string Status =>
            ItemsCount == 0
                ? "Чернова"
                : TotalAmount <= 0
                    ? "Без стойност"
                    : "Обработена";
    }
}