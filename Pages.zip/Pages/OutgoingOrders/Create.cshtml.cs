﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrders
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public OutgoingOrder Order { get; set; } = new();

        public List<SelectListItem> ClientStores { get; set; } = new();
        public List<SelectListItem> Stores { get; set; } = new();

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadDropdowns();

            Order.Date = DateTime.Now;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDropdowns();

            if (!ModelState.IsValid)
                return Page();

            if (Order.ClientStoreId <= 0 || Order.StoreId <= 0)
            {
                ModelState.AddModelError("", "Моля изберете клиент и склад.");
                return Page();
            }

            try
            {
                if (Order.Date == default)
                    Order.Date = DateTime.Now;

                Order.OutgoingOrderDetails = new List<OutgoingOrderDetail>();

                _context.OutgoingOrders.Add(Order);
                await _context.SaveChangesAsync(); 

                Order.Number = Order.Id;

                await _context.SaveChangesAsync();

                return RedirectToPage(
                    "/OutgoingOrdersDetails/Create",
                    new { outgoingOrderId = Order.Id });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Грешка при запис: " + ex.Message);
                return Page();
            }
        }

        private async Task LoadDropdowns()
        {
            ClientStores = await _context.ClientStores
                .AsNoTracking()
                .OrderBy(x => x.Name)
                .Select(x => new SelectListItem
                {
                    Value = x.ClientStoreId.ToString(),
                    Text = x.Name
                })
                .ToListAsync();

            Stores = await _context.Stores
                .AsNoTracking()
                .OrderBy(x => x.Name)
                .Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Name
                })
                .ToListAsync();
        }
    }
}