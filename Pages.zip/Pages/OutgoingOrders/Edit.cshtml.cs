﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.OutgoingOrders
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public OutgoingOrder Order { get; set; } = new();

        public List<SelectListItem> ClientStores { get; set; } = new();
        public List<SelectListItem> Stores { get; set; } = new();

        public bool HasDetails { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Order = await _context.OutgoingOrders
                .AsNoTracking()
                .Include(x => x.ClientStore)
                .Include(x => x.Store)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (Order == null)
                return NotFound();

            HasDetails = await _context.OutgoingOrderDetails
                .AnyAsync(x => x.OutgoingOrderId == id);

            await LoadDropdowns();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDropdowns();

            if (!ModelState.IsValid)
                return Page();

            var existingOrder = await _context.OutgoingOrders
                .FirstOrDefaultAsync(x => x.Id == Order.Id);

            if (existingOrder == null)
                return NotFound();

            HasDetails = await _context.OutgoingOrderDetails
                .AnyAsync(x => x.OutgoingOrderId == Order.Id);

            if (HasDetails && existingOrder.StoreId != Order.StoreId)
            {
                ModelState.AddModelError("",
                    "Не може да се промени складът, защото има добавени артикули.");

                Order = existingOrder;
                return Page();
            }

            existingOrder.ClientStoreId = Order.ClientStoreId;

            if (!HasDetails)
            {
                existingOrder.StoreId = Order.StoreId;
            }

            await _context.SaveChangesAsync();

            return RedirectToPage("./Details",
                new { id = existingOrder.Id });
        }

        private async Task LoadDropdowns()
        {
            ClientStores = await _context.ClientStores
                .AsNoTracking()
                .OrderBy(x => x.Name)
                .Select(x => new SelectListItem
                {
                    Value = x.ClientStoreId.ToString(),
                    Text = x.Name
                })
                .ToListAsync();

            Stores = await _context.Stores
                .AsNoTracking()
                .OrderBy(x => x.Name)
                .Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Name
                })
                .ToListAsync();
        }
    }
}