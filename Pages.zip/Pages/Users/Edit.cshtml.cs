﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Users
{
    [Authorize(Roles = "Admin")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public User User { get; set; } = new();

        public List<Worker> Workers { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            await LoadWorkersAsync();

            var user = await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
                return RedirectToPage("/Users/Index");

            User = user;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadWorkersAsync();

            if (!ModelState.IsValid)
                return Page();

            var userInDb = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == User.Id);

            if (userInDb == null)
                return RedirectToPage("/Users/Index");

            var usernameExists = await _context.Users
                .AnyAsync(u => u.Username == User.Username && u.Id != User.Id);

            if (usernameExists)
            {
                ModelState.AddModelError(string.Empty, "Потребителското име вече съществува.");
                return Page();
            }

            if (userInDb.Role == "Admin" && User.Role != "Admin")
            {
                ModelState.AddModelError("", "Не може да премахнете Admin роля.");
                return Page();
            }

            userInDb.Username = User.Username;
            userInDb.Role = User.Role;

       
            userInDb.WorkerId = User.WorkerId;

            await _context.SaveChangesAsync();

            return RedirectToPage("/Users/Index");
        }

        private async Task LoadWorkersAsync()
        {
            Workers = await _context.Workers
                .AsNoTracking()
                .ToListAsync();
        }
    }
}