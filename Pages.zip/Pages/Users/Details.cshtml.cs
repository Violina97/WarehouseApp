﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Users
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public User? User { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            User = await _context.Users
                .Include(u => u.Worker)
                .FirstOrDefaultAsync(u => u.Id == id);

            if (User == null)
                return RedirectToPage("./Index");

            return Page();
        }
    }
}