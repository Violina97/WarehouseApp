using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Users
{
    [Authorize(Roles = "Admin")]
    public class ChangePasswordModel : PageModel
    {
        private readonly WarehouseContext _context;

        public ChangePasswordModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public int UserId { get; set; }

        [BindProperty]
        public string OldPassword { get; set; }

        [BindProperty]
        public string NewPassword { get; set; }

        [BindProperty]
        public string ConfirmPassword { get; set; }

        public User User { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            User = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == id);

            if (User == null)
                return RedirectToPage("/Users/Index");

            UserId = id;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            User = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == UserId);

            if (User == null)
                return RedirectToPage("/Users/Index");

            if (NewPassword != ConfirmPassword)
            {
                ModelState.AddModelError("", "Новата парола и потвърждението не съвпадат.");
                return Page();
            }

            var isOldPasswordValid = BCrypt.Net.BCrypt.Verify(OldPassword, User.Password);

            if (!isOldPasswordValid)
            {
                ModelState.AddModelError("", "Старата парола е грешна.");
                return Page();
            }

            User.Password = BCrypt.Net.BCrypt.HashPassword(NewPassword);

            await _context.SaveChangesAsync();

            return RedirectToPage("/Users/Index");
        }
    }
}