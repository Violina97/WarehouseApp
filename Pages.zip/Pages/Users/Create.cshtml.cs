﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace WarehouseApp.Pages.Users
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public User User { get; set; } = new();

        public List<Worker> Workers { get; set; } = new();

        public async Task OnGetAsync()
        {
            await LoadWorkersAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadWorkersAsync();

            if (!ModelState.IsValid)
                return Page();

            
            var exists = await _context.Users
                .AnyAsync(u => u.Username == User.Username);

            if (exists)
            {
                ModelState.AddModelError("", "Потребителското име вече съществува.");
                return Page();
            }

            
            User.Password = BCrypt.Net.BCrypt.HashPassword(User.Password);

            
            if (User.Role == "Admin")
            {
                User.WorkerId = null;
            }

            _context.Users.Add(User);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Users/Index");
        }

        private async Task LoadWorkersAsync()
        {
            Workers = await _context.Workers
                .AsNoTracking()
                .ToListAsync();
        }
    }
}