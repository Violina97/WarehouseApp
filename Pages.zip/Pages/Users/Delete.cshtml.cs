﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Users
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public User User { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            User = await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Id == id);

            if (User == null)
                return NotFound();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
                return NotFound();


            if (user.WorkerId.HasValue)
            {
                var hasInvoices = await _context.InvoiceMasters
                    .AnyAsync(i => i.WorkerId == user.WorkerId.Value);

                var hasDeliveries = await _context.DeliveryMasters
                    .AnyAsync(d => d.WorkerId == user.WorkerId.Value);


                if (hasInvoices || hasDeliveries)
                {
                    ModelState.AddModelError("",
                        "Не може да се изтрие потребител, който има издадени фактури или доставки.");

                    User = user;
                    return Page();
                }
            }


            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Users/Index");
        }
    }
}