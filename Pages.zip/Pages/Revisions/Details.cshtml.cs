﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Revisions
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Revision Revision { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Revision = await _context.Revisions
                .Include(r => r.Store)
                .Include(r => r.Product)
                .Include(r => r.Worker)
                .FirstOrDefaultAsync(r => r.RevisionId == id);

            if (Revision == null)
                return NotFound();

            return Page();
        }
    }
}