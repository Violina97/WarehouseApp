﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Revisions
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Revision Revision { get; set; } = new Revision();

        public SelectList StoresList { get; set; } = default!;
        public SelectList ProductsList { get; set; } = default!;
        public SelectList WorkersList { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadDataAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDataAsync();

            if (!ModelState.IsValid)
                return Page();

            _context.Revisions.Add(Revision);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadDataAsync()
        {
            StoresList = new SelectList(
                await _context.Stores.ToListAsync(),
                "Id",
                "Name"
            );

            ProductsList = new SelectList(
                await _context.Products.ToListAsync(),
                "Id",
                "Name"
            );

            WorkersList = new SelectList(
                await _context.Workers
                    .Select(w => new
                    {
                        w.WorkerId,
                        FullName = w.FirstName + " " + w.LastName
                    })
                    .ToListAsync(),
                "WorkerId",
                "FullName"
            );
        }
    }
}