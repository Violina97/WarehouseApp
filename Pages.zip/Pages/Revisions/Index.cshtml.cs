﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Revisions
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public IList<Revision> Revisions { get; set; } = new List<Revision>();

        public async Task OnGetAsync()
        {
            Revisions = await _context.Revisions
                .Include(r => r.Store)
                .Include(r => r.Product)
                .Include(r => r.Worker)
                .OrderByDescending(r => r.RevisionDate)
                .ToListAsync();
        }
    }
}