﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Revisions
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Revision Revision { get; set; } = default!;

        public SelectList StoresList { get; set; } = default!;
        public SelectList ProductsList { get; set; } = default!;
        public SelectList WorkersList { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Revision = await _context.Revisions.FirstOrDefaultAsync(r => r.RevisionId == id);

            if (Revision == null)
                return NotFound();

            await LoadDataAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDataAsync();

            if (!ModelState.IsValid)
                return Page();

            var dbRevision = await _context.Revisions
                .FirstOrDefaultAsync(r => r.RevisionId == Revision.RevisionId);

            if (dbRevision == null)
                return NotFound();

            dbRevision.StoreId = Revision.StoreId;
            dbRevision.ProductId = Revision.ProductId;
            dbRevision.WorkerId = Revision.WorkerId;
            dbRevision.Quantity = Revision.Quantity;
            dbRevision.RevisionDate = Revision.RevisionDate;

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadDataAsync()
        {
            StoresList = new SelectList(await _context.Stores.ToListAsync(), "Id", "Name");

            ProductsList = new SelectList(await _context.Products.ToListAsync(), "Id", "Name");

            WorkersList = new SelectList(
                await _context.Workers
                    .Select(w => new
                    {
                        w.WorkerId,
                        FullName = w.FirstName + " " + w.LastName
                    })
                    .ToListAsync(),
                "WorkerId",
                "FullName"
            );
        }
    }
}