using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.Reports
{
    public class StockReportModel : PageModel
    {
        private readonly WarehouseContext _context;

        public StockReportModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public int? StoreId { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? ProductId { get; set; }

        [BindProperty(SupportsGet = true)]
        public bool LowStockOnly { get; set; } = false;

        public SelectList Stores { get; set; } = default!;
        public SelectList Products { get; set; } = default!;

       
        public class StockVm
        {
            public string StoreName { get; set; } = "";
            public string ProductName { get; set; } = "";
            public decimal Stock { get; set; }
        }

        public List<StockVm> Items { get; set; } = new();

        public async Task OnGetAsync()
        {
            
            Stores = new SelectList(
                await _context.Stores
                    .AsNoTracking()
                    .OrderBy(s => s.Name)
                    .ToListAsync(),
                "Id",
                "Name"
            );

          
            Products = new SelectList(
                await _context.Products
                    .AsNoTracking()
                    .OrderBy(p => p.Name)
                    .ToListAsync(),
                "Id",
                "Name"
            );

            
            var incomingQuery = _context.DeliveryDetails
                .Include(d => d.DeliveryMaster)
                .AsQueryable();

            if (StoreId.HasValue)
                incomingQuery = incomingQuery.Where(d => d.DeliveryMaster.StoreId == StoreId);

            if (ProductId.HasValue)
                incomingQuery = incomingQuery.Where(d => d.ProductId == ProductId);

            var incoming = await incomingQuery
                .GroupBy(x => new { x.DeliveryMaster.StoreId, x.ProductId })
                .Select(g => new
                {
                    g.Key.StoreId,
                    g.Key.ProductId,
                    Qty = g.Sum(x => x.Quantity)
                })
                .ToListAsync();

            
            var outgoingQuery = _context.OutgoingOrderDetails
                .Include(o => o.OutgoingOrder)
                .AsQueryable();

            if (StoreId.HasValue)
                outgoingQuery = outgoingQuery.Where(o => o.OutgoingOrder.StoreId == StoreId);

            if (ProductId.HasValue)
                outgoingQuery = outgoingQuery.Where(o => o.ProductId == ProductId);

            var outgoing = await outgoingQuery
                .GroupBy(x => new { x.OutgoingOrder.StoreId, x.ProductId })
                .Select(g => new
                {
                    g.Key.StoreId,
                    g.Key.ProductId,
                    Qty = g.Sum(x => x.Quantity)
                })
                .ToListAsync();

            
            var products = await _context.Products.AsNoTracking().ToListAsync();
            var stores = await _context.Stores.AsNoTracking().ToListAsync();

            Items =
                (
                    from i in incoming
                    join s in stores on i.StoreId equals s.Id
                    join p in products on i.ProductId equals p.Id
                    join o in outgoing
                        on new { i.StoreId, i.ProductId }
                        equals new { o.StoreId, o.ProductId }
                        into og
                    from o in og.DefaultIfEmpty()

                    select new StockVm
                    {
                        StoreName = s.Name,
                        ProductName = p.Name,
                        Stock = i.Qty - (o?.Qty ?? 0)
                    }
                )
                .Where(x => x.Stock > 0)
                .ToList();

         
            if (LowStockOnly)
            {
                Items = Items.Where(x => x.Stock <= 10).ToList();
            }

            Items = Items
                .OrderBy(x => x.StoreName)
                .ThenBy(x => x.ProductName)
                .ToList();
        }
    }
}