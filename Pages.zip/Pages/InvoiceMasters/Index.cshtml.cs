﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        [BindProperty(SupportsGet = true)]
        public string SortBy { get; set; } = "date";

        public IndexModel(WarehouseContext context)
        {
            _context = context;

        }

        public IList<InvoiceMaster> InvoiceMasters { get; set; }
            = new List<InvoiceMaster>();

        public async Task OnGetAsync()
        {
            var query = _context.InvoiceMasters
                .Include(i => i.Client)
                .Include(i => i.Worker)
                .AsQueryable();

           

            if (SortBy == "number")
            {
                query = query.OrderByDescending(x => x.Number);
            }
            else
            {
                query = query.OrderByDescending(x => x.InvoiceDate);
            }

            InvoiceMasters = await query.ToListAsync();
        }
    }
}