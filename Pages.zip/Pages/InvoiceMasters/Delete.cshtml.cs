﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.InvoiceMasters
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Models.InvoiceMaster InvoiceMaster { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            InvoiceMaster = await _context.InvoiceMasters
                .Include(i => i.Client)
                .FirstOrDefaultAsync(i => i.InvoiceMId == id);

            if (InvoiceMaster == null)
                return NotFound();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();

            var invoice = await _context.InvoiceMasters
                .Include(i => i.InvoiceDetails)
                .FirstOrDefaultAsync(i => i.InvoiceMId == id);

            if (invoice == null)
                return NotFound();

          
            _context.InvoiceDetails.RemoveRange(invoice.InvoiceDetails);

            _context.InvoiceMasters.Remove(invoice);

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}