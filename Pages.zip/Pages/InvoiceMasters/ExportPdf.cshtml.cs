using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.InvoiceMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class ExportPdfModel : PageModel
    {
        private readonly WarehouseContext _context;

        public ExportPdfModel(WarehouseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> OnGet(int id)
        {
            var invoice = await _context.InvoiceMasters
                .Include(i => i.Client)
                .Include(i => i.InvoiceDetails)
                    .ThenInclude(d => d.Product)
                .FirstOrDefaultAsync(i => i.InvoiceMId == id);

            if (invoice == null)
                return NotFound();

            var document = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(30);
                    page.DefaultTextStyle(x => x.FontSize(11));

                    
                    page.Header().Column(col =>
                    {
                        col.Item().Row(row =>
                        {
                            row.RelativeItem().Column(left =>
                            {
                                left.Item().Text("ФАКТУРА")
                                    .FontSize(26)
                                    .Bold();

                                left.Item().Text($"№ INV-{invoice.InvoiceMId:000000}")
                                    .FontSize(14)
                                    .SemiBold();

                                left.Item().Text($"Дата: {invoice.InvoiceDate:dd.MM.yyyy}");
                            });

                            row.ConstantItem(150).AlignRight().Column(right =>
                            {
                                right.Item().Text("WarehouseApp")
                                    .Bold()
                                    .FontSize(14);

                                right.Item().Text("Складова система");
                            });
                        });
                    });

                   
                    page.Content().Column(col =>
                    {
                        col.Spacing(10);

                        
                        col.Item().PaddingVertical(10).Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().Text("КЛИЕНТ").Bold();
                                c.Item().Text(invoice.Client?.Name ?? "-");
                            });

                            row.RelativeItem().Column(c =>
                            {
                                c.Item().Text("СЛУЖИТЕЛ").Bold();
                                c.Item().Text(invoice.Worker != null
                                    ? invoice.Worker.FirstName + " " + invoice.Worker.LastName
                                    : "-");
                            });
                        });

                        
                        col.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.RelativeColumn(5); 
                                columns.RelativeColumn(2); 
                                columns.RelativeColumn(3); 
                                columns.RelativeColumn(3); 
                            });

                            // HEADER
                            table.Header(header =>
                            {
                                header.Cell().Background("#1F2937").Padding(5)
                                    .Text("Продукт").FontColor("#fff").Bold();

                                header.Cell().Background("#1F2937").Padding(5)
                                    .Text("Кол.").FontColor("#fff").Bold();

                                header.Cell().Background("#1F2937").Padding(5)
                                    .Text("Ед. цена").FontColor("#fff").Bold();

                                header.Cell().Background("#1F2937").Padding(5)
                                    .Text("Сума").FontColor("#fff").Bold();
                            });

                            
                            foreach (var item in invoice.InvoiceDetails)
                            {
                                table.Cell().Padding(5)
                                    .Text(item.Product?.Name ?? "");

                                table.Cell().Padding(5)
                                    .Text(item.Quantity.ToString());

                                table.Cell().Padding(5)
                                    .Text($"{item.Price:0.00} €");

                                table.Cell().Padding(5)
                                    .Text($"{item.Price * item.Quantity:0.00} €");
                            }
                        });

                        
                        col.Item().AlignRight().PaddingTop(15).Column(c =>
                        {
                            c.Item()
                           .AlignRight()
                           .Background("#F3F4F6")
                           .Padding(12)
                           .Text(text =>
    {
        text.Span("ОБЩО: ").Bold();
        text.Span($"{invoice.Total:0.00} €").FontSize(16);
    });
                        });
                    });

                    
                    page.Footer()
                        .AlignCenter()
                        .Text("Warehouse Management System • Автоматично генериран документ")
                        .FontSize(9)
                        .FontColor("#6B7280");
                });
            });

            var stream = new MemoryStream();
            document.GeneratePdf(stream);
            stream.Position = 0;

            return File(stream.ToArray(), "application/pdf", $"Invoice_{invoice.InvoiceMId}.pdf");
        }
    }
}