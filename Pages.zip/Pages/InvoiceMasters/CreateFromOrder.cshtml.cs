using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceMasters
{
    public class CreateFromOrderModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateFromOrderModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public int OrderId { get; set; }

        public async Task<IActionResult> OnGetAsync(int orderId)
        {
            var order = await _context.OutgoingOrders
                .Include(o => o.OutgoingOrderDetails)
                    .ThenInclude(d => d.Product)
                .Include(o => o.ClientStore)
                .FirstOrDefaultAsync(o => o.Id == orderId);

            if (order == null)
                return NotFound();

           
            var invoice = new InvoiceMaster
            {
                ClientId = order.ClientStoreId,
                WorkerId = 1, 
                InvoiceDate = DateTime.Now,
                Receiver = order.ClientStore?.Name,
            };

            _context.InvoiceMasters.Add(invoice);
            await _context.SaveChangesAsync();

            
            invoice.Number = invoice.InvoiceMId;

            _context.Attach(invoice);
            _context.Entry(invoice).Property(x => x.Number).IsModified = true;
            await _context.SaveChangesAsync();

          
            foreach (var item in order.OutgoingOrderDetails)
            {
                _context.InvoiceDetails.Add(new InvoiceDetail
                {
                    InvoiceMId = invoice.InvoiceMId,
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Price = item.Product.Price
                });
            }

            await _context.SaveChangesAsync();

            return RedirectToPage("/InvoiceDetails/Create",
                new { invoiceMId = invoice.InvoiceMId });
        }
    }
}