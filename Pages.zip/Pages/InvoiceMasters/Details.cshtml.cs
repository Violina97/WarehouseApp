﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.InvoiceMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Models.InvoiceMaster InvoiceMaster { get; set; }

        public decimal Total { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            InvoiceMaster = await _context.InvoiceMasters
                .Include(i => i.Client)
                .Include(i => i.Worker)
                .Include(i => i.InvoiceDetails)
                    .ThenInclude(d => d.Product)
                .FirstOrDefaultAsync(i => i.InvoiceMId == id);

            if (InvoiceMaster == null)
                return NotFound();

            Total = InvoiceMaster.InvoiceDetails?
                .Sum(d => d.Quantity * d.Price) ?? 0;

            return Page();
        }
    }
}