﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InvoiceMaster InvoiceMaster { get; set; } = new();

        public SelectList Clients { get; set; }
        public SelectList Workers { get; set; }

        public async Task OnGetAsync()
        {
            await LoadDataAsync();

            InvoiceMaster.InvoiceDate = DateTime.Now;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDataAsync();

            if (!ModelState.IsValid)
                return Page();

            try
            {
                _context.InvoiceMasters.Add(InvoiceMaster);
                await _context.SaveChangesAsync();

                InvoiceMaster.Number = InvoiceMaster.InvoiceMId;

                _context.InvoiceMasters.Attach(InvoiceMaster);
                _context.Entry(InvoiceMaster).Property(x => x.Number).IsModified = true;

                await _context.SaveChangesAsync();

                return RedirectToPage(
                    "/InvoiceDetails/Create",
                    new { invoiceMId = InvoiceMaster.InvoiceMId });
            }
            catch (Exception)
            {
                ModelState.AddModelError(string.Empty, "Възникна грешка при запис.");
                return Page();
            }
        }

        private async Task LoadDataAsync()
        {
            Clients = new SelectList(
                await _context.Clients
                    .AsNoTracking()
                    .OrderBy(c => c.Name)
                    .ToListAsync(),
                "ClientId",
                "Name"
            );

            Workers = new SelectList(
                await _context.Workers
                    .AsNoTracking()
                    .Select(w => new
                    {
                        w.WorkerId,
                        FullName = w.FirstName + " " + w.LastName
                    })
                    .ToListAsync(),
                "WorkerId",
                "FullName"
            );
        }
    }
}