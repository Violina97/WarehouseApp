﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;

namespace WarehouseApp.Pages.InvoiceMasters
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Models.InvoiceMaster InvoiceMaster { get; set; }

        public SelectList Clients { get; set; }

        public SelectList Workers { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            InvoiceMaster = await _context.InvoiceMasters
                .FirstOrDefaultAsync(i => i.InvoiceMId == id);

            if (InvoiceMaster == null)
                return NotFound();

            await LoadDataAsync();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDataAsync();

            if (!ModelState.IsValid)
                return Page();

            var dbInvoice = await _context.InvoiceMasters
                .FirstOrDefaultAsync(i => i.InvoiceMId == InvoiceMaster.InvoiceMId);

            if (dbInvoice == null)
                return NotFound();

       
            dbInvoice.Number = InvoiceMaster.Number;
            dbInvoice.InvoiceDate = InvoiceMaster.InvoiceDate;
            dbInvoice.ClientId = InvoiceMaster.ClientId;
            dbInvoice.WorkerId = InvoiceMaster.WorkerId;
            dbInvoice.Receiver = InvoiceMaster.Receiver;

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadDataAsync()
        {
            Clients = new SelectList(
                await _context.Clients
                    .AsNoTracking()
                    .OrderBy(c => c.Name)
                    .ToListAsync(),
                "ClientId",
                "Name"
            );

            Workers = new SelectList(
                await _context.Workers
                    .AsNoTracking()
                    .Select(w => new
                    {
                        w.WorkerId,
                        FullName = w.FirstName + " " + w.LastName
                    })
                    .ToListAsync(),
                "WorkerId",
                "FullName"
            );
        }
    }
}