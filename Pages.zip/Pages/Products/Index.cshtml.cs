﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Products
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public string? SearchString { get; set; }

        
        public class ProductVm
        {
            public int Id { get; set; }
            public string Name { get; set; } = "";
            public string? Description { get; set; }
            public decimal Price { get; set; }
            public string Measure { get; set; } = "";

            public decimal DiscountQuantity { get; set; }
            public decimal DiscountPercent { get; set; }

          
        }

        public IList<ProductVm> Product { get; set; } = new List<ProductVm>();

        public async Task OnGetAsync()
        {
            var query = _context.Products
                .AsNoTracking()
                .Include(p => p.Measure)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(SearchString))
            {
                string search = SearchString.Trim();

                query = query.Where(p =>
                    p.Name.Contains(search) ||
                    (p.Description != null && p.Description.Contains(search))
                );
            }
            Product = await query
                .Select(p => new ProductVm
                {
                    Id = p.Id,
                    Name = p.Name,
                    Description = p.Description,
                    Price = p.Price,
                    Measure = p.Measure != null ? p.Measure.MeasureName : "",

                    DiscountQuantity = p.DiscountQuantity,
                    DiscountPercent = p.DiscountPercent,

                   })
                   .ToListAsync();
        }
    }
}
