﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Products
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Product Product { get; set; } = new Product();

        public Promotion? ActivePromotion { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Product = await _context.Products
                .Include(p => p.Measure)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (Product == null)
                return NotFound();

          
            ActivePromotion = await _context.Promotions
                .FirstOrDefaultAsync(p =>
                    p.ProductId == id &&
                    p.Validity >= DateTime.Now);

            return Page();
        }
    }
}