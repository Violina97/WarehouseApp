﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Products
{
    [Authorize(Roles = "Admin,Employee")]
   
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Product Product { get; set; } = new Product();

        
        public void OnGet()
        {
            ViewData["MeasureId"] = new SelectList(_context.Measures, "MeasureId", "MeasureName");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                ViewData["MeasureId"] = new SelectList(_context.Measures, "MeasureId", "MeasureName");
                return Page();
            }

            _context.Products.Add(Product);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}