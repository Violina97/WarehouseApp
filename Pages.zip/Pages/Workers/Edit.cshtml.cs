﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace WarehouseApp.Pages.Workers
{
    [Authorize(Roles = "Admin")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Worker Worker { get; set; } = new();

        public List<SelectListItem> Stores { get; set; } = new();

        public List<SelectListItem> Positions { get; set; } = new();


        public async Task<IActionResult> OnGetAsync(int id)
        {
            Worker = await _context.Workers.FindAsync(id);

            if (Worker == null)
                return NotFound();

            await LoadDataAsync();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await LoadDataAsync();
                return Page();
            }

            var worker = await _context.Workers
                .FindAsync(Worker.WorkerId);

            if (worker == null)
                return NotFound();


   
            worker.FirstName = Worker.FirstName;
            worker.MiddleName = Worker.MiddleName;
            worker.LastName = Worker.LastName;
            worker.EGN = Worker.EGN;
            worker.Telephone = Worker.Telephone;
            worker.Address = Worker.Address;
            worker.StoreId = Worker.StoreId;
            worker.PositionId = Worker.PositionId;


            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }

        
        private async Task LoadDataAsync()
        {
            Stores = await _context.Stores
                .Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Name
                })
                .ToListAsync();


            Positions = await _context.Positions
                .Select(p => new SelectListItem
                {
                    Value = p.PositionId.ToString(),
                    Text = p.PositionName
                })
                .ToListAsync();
        }
    }
}