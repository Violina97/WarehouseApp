﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace WarehouseApp.Pages.Workers
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public List<Worker> Workers { get; set; } = new();

        public async Task OnGetAsync()
        {
            Workers = await _context.Workers
                .Include(w => w.Store)
                .Include(w => w.Position)
                .ToListAsync();
        }
    }
}