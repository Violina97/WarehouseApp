﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace WarehouseApp.Pages.Workers
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Worker Worker { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Worker = await _context.Workers
                .Include(w => w.Store)
                .Include(w => w.Position)
                .FirstOrDefaultAsync(w => w.WorkerId == id);

            if (Worker == null)
                return NotFound();

            return Page();
        }
    }
}