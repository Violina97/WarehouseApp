﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace WarehouseApp.Pages.Workers
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Worker Worker { get; set; } = new();

        public List<SelectListItem> Stores { get; set; } = new();
        public List<SelectListItem> Positions { get; set; } = new();

        public async Task OnGetAsync()
        {
            Stores = await _context.Stores
                .Select(s => new SelectListItem
                {
                    Value = s.Id.ToString(),
                    Text = s.Name
                }).ToListAsync();

            Positions = await _context.Positions
                .Select(p => new SelectListItem
                {
                    Value = p.PositionId.ToString(),
                    Text = p.PositionName
                }).ToListAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();

            _context.Workers.Add(Worker);
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}