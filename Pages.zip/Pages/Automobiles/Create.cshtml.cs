﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Automobiles
{
    [Authorize(Roles = "Admin")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Automobile Automobile { get; set; }

        public SelectList Brands { get; set; }

        public IActionResult OnGet()
        {
            Brands = new SelectList(_context.AutomobileBrands, "Id", "BrandName");
            return Page();
        }

        
        public async Task<IActionResult> OnPostAsync()
        {
            _context.Automobiles.Add(Automobile); 
            await _context.SaveChangesAsync();    

            return RedirectToPage("./Index");
        }
    }
}