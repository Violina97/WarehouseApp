﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Automobiles
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Automobile Automobile { get; set; }

        
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Automobile = await _context.Automobiles.FindAsync(id);

            if (Automobile == null)
                return NotFound();

            return Page();
        }

    
        public async Task<IActionResult> OnPostAsync(int id)
        {
            var item = await _context.Automobiles.FindAsync(id);

            if (item != null)
            {
                _context.Automobiles.Remove(item);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}