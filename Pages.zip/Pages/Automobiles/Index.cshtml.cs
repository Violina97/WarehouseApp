﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Automobiles
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public IList<Automobile> Automobile { get; set; } = default!;

        public async Task OnGetAsync()
        {
            Automobile = await _context.Automobiles
                .Include(a => a.AutomobileBrand) 
                .ToListAsync();
        }
    }
}