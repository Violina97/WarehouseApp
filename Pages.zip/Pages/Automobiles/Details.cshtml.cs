﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Automobiles
{
    [Authorize(Roles = "Admin")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Automobile Automobile { get; set; }

       
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Automobile = await _context.Automobiles
                .Include(a => a.AutomobileBrand)
                .FirstOrDefaultAsync(m => m.AutoId == id);

            if (Automobile == null)
                return NotFound();

            return Page();
        }
    }
}