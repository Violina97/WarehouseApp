﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public InvoiceDetail InvoiceDetail { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            InvoiceDetail = await _context.InvoiceDetails
                .Include(i => i.Product)
                .Include(i => i.InvoiceMaster)
                    .ThenInclude(m => m.Client)
                .FirstOrDefaultAsync(i => i.InvoiceDId == id);

            if (InvoiceDetail == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}