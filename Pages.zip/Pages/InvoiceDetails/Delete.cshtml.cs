﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceDetails
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InvoiceDetail InvoiceDetail { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            InvoiceDetail = await _context.InvoiceDetails
                .Include(i => i.Product)
                .FirstOrDefaultAsync(i => i.InvoiceDId == id);

            if (InvoiceDetail == null)
                return NotFound();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();

            var detail = await _context.InvoiceDetails
                .FirstOrDefaultAsync(i => i.InvoiceDId == id);

            if (detail == null)
                return NotFound();

            int invoiceId = detail.InvoiceMId;

            _context.InvoiceDetails.Remove(detail);
            await _context.SaveChangesAsync();

            return RedirectToPage("/InvoiceDetails/Create",
                new { invoiceMId = invoiceId });
        }
    }
}