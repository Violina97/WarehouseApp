﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        public InvoiceMaster? InvoiceMaster { get; set; }

        [BindProperty]
        public InvoiceDetail InvoiceDetail { get; set; } = new();

        public SelectList Products { get; set; } = default!;

        public List<InvoiceDetail> Details { get; set; } = new();

        public decimal Total { get; set; }

       
        public async Task<IActionResult> OnGetAsync(int invoiceMId)
        {
            await LoadInvoice(invoiceMId);

            if (InvoiceMaster == null)
                return RedirectToPage("/InvoiceMasters/Index");

            InvoiceDetail.InvoiceMId = invoiceMId;

            LoadProducts();

            await LoadDetails(invoiceMId);

            return Page();
        }

       
        public async Task<IActionResult> OnPostAsync()
        {
            LoadProducts();

            var invoiceId = InvoiceDetail.InvoiceMId;

            if (invoiceId <= 0)
                return RedirectToPage("/InvoiceMasters/Index");

            if (InvoiceDetail.ProductId <= 0)
            {
                ModelState.AddModelError("InvoiceDetail.ProductId", "Изберете продукт.");
                await LoadInvoice(invoiceId);
                await LoadDetails(invoiceId);
                return Page();
            }

            if (InvoiceDetail.Quantity <= 0)
            {
                ModelState.AddModelError("InvoiceDetail.Quantity", "Количество трябва да е > 0.");
                await LoadInvoice(invoiceId);
                await LoadDetails(invoiceId);
                return Page();
            }

            if (!ModelState.IsValid)
            {
                await LoadInvoice(invoiceId);
                await LoadDetails(invoiceId);
                return Page();
            }

            var product = await _context.Products
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Id == InvoiceDetail.ProductId);

            if (product == null)
            {
                ModelState.AddModelError("", "Невалиден продукт.");
                await LoadInvoice(invoiceId);
                await LoadDetails(invoiceId);
                return Page();
            }

            InvoiceDetail.Price = product.Price;

            _context.InvoiceDetails.Add(InvoiceDetail);
            await _context.SaveChangesAsync();

            return RedirectToPage(new { invoiceMId = invoiceId });
        }

        private async Task LoadInvoice(int invoiceMId)
        {
            InvoiceMaster = await _context.InvoiceMasters
                .Include(i => i.Client)
                .Include(i => i.Worker)
                .FirstOrDefaultAsync(i => i.InvoiceMId == invoiceMId);
        }

        private void LoadProducts()
        {
            Products = new SelectList(
                _context.Products
                    .AsNoTracking()
                    .OrderBy(p => p.Name)
                    .Select(p => new { p.Id, p.Name })
                    .ToList(),
                "Id",
                "Name"
            );
        }

        private async Task LoadDetails(int invoiceMId)
        {
            Details = await _context.InvoiceDetails
                .Include(d => d.Product)
                .Where(d => d.InvoiceMId == invoiceMId)
                .ToListAsync();

            Total = Details.Sum(d => d.Quantity * d.Price);
        }
    }
}