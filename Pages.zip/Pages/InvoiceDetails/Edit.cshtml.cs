﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InvoiceDetail InvoiceDetail { get; set; }

        public SelectList Products { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            InvoiceDetail = await _context.InvoiceDetails
                .FirstOrDefaultAsync(x => x.InvoiceDId == id);

            if (InvoiceDetail == null)
                return NotFound();

            await LoadProducts();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadProducts();

            if (!ModelState.IsValid)
                return Page();

            var existing = await _context.InvoiceDetails
                .FirstOrDefaultAsync(x => x.InvoiceDId == InvoiceDetail.InvoiceDId);

            if (existing == null)
                return NotFound();

            var product = await _context.Products
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Id == InvoiceDetail.ProductId);

            if (product == null)
            {
                ModelState.AddModelError("", "Невалиден продукт.");
                return Page();
            }

            
            existing.ProductId = InvoiceDetail.ProductId;
            existing.Quantity = InvoiceDetail.Quantity;
            existing.Price = product.Price;

            await _context.SaveChangesAsync();

            return RedirectToPage("/InvoiceDetails/Create",
                new { invoiceMId = existing.InvoiceMId });
        }

        private async Task LoadProducts()
        {
            Products = new SelectList(
                await _context.Products
                    .AsNoTracking()
                    .OrderBy(p => p.Name)
                    .ToListAsync(),
                "Id",
                "Name"
            );
        }
    }
}