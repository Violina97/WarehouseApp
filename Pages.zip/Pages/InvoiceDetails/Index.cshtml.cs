﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.InvoiceDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public InvoiceMaster InvoiceMaster { get; set; }

        public List<InvoiceDetail> Details { get; set; } = new();

        public decimal Total { get; set; }

        public async Task<IActionResult> OnGetAsync(int? invoiceMId)
        {
            if (invoiceMId == null)
                return RedirectToPage("/InvoiceMasters/Index");

            InvoiceMaster = await _context.InvoiceMasters
                .Include(i => i.Client)
                .Include(i => i.Worker)
                .FirstOrDefaultAsync(i => i.InvoiceMId == invoiceMId);

            if (InvoiceMaster == null)
                return NotFound();

            Details = await _context.InvoiceDetails
                .Include(d => d.Product)
                .Where(d => d.InvoiceMId == invoiceMId)
                .ToListAsync();

            Total = Details.Sum(d => d.Quantity * d.Price);

            return Page();
        }
    }
}