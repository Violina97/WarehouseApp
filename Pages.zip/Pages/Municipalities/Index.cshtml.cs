﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Municipalities
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public List<Municipality> Municipalities { get; set; } = new();


        public async Task OnGetAsync()
        {
            Municipalities = await _context.Municipalities
                .Include(m => m.Region)
                .ToListAsync();
        }
    }
}