﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Municipalities
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        public Municipality Municipality { get; set; } = new();

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Municipality = await _context.Municipalities
                .Include(m => m.Region)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (Municipality == null)
                return NotFound();

            return Page();
        }


        public async Task<IActionResult> OnPostAsync(int id)
        {
            var entity = await _context.Municipalities.FindAsync(id);

            if (entity != null)
            {
                _context.Municipalities.Remove(entity);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("Index");
        }
    }
}