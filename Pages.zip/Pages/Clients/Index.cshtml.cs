﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Clients
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public IList<Client> Client { get; set; } = new List<Client>();

        public async Task OnGetAsync()
        {
           
            Client = await _context.Clients
                .Include(c => c.City)
                .OrderByDescending(c => c.ClientId)
                .ToListAsync();
        }
    }
}