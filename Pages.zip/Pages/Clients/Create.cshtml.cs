﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Clients
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        public SelectList Cities { get; set; }

        [BindProperty]
        public Client Client { get; set; } = new Client();

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadCities();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await LoadCities();
                return Page();
            }

            Client.CreatedAt = DateTime.Now;

            _context.Clients.Add(Client);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadCities()
        {
            
            Cities = new SelectList(
                await _context.Cities.ToListAsync(),
                "CityId",
                "CityName"
            );
        }
    }
}