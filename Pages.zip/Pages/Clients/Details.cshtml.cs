﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Clients
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Client Client { get; set; } = new Client();

     
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            Client = await _context.Clients
                .Include(c => c.City)
                .FirstOrDefaultAsync(c => c.ClientId == id);

            if (Client == null)
                return NotFound();

            return Page();
        }
    }
}