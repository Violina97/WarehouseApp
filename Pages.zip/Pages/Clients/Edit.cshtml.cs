﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Clients
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Client Client { get; set; } = new Client();

        public SelectList Cities { get; set; }

    
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();

            Client = await _context.Clients
                .FirstOrDefaultAsync(c => c.ClientId == id);

            if (Client == null)
                return NotFound();

            await LoadCities(Client.CityId);

            return Page();
        }

     
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await LoadCities(Client.CityId);
                return Page();
            }

            var clientFromDb = await _context.Clients
                .FirstOrDefaultAsync(c => c.ClientId == Client.ClientId);

            if (clientFromDb == null)
                return NotFound();

            clientFromDb.Name = Client.Name;
            clientFromDb.Bulstat = Client.Bulstat;
            clientFromDb.RegistryNumber = Client.RegistryNumber;
            clientFromDb.Address = Client.Address;
            clientFromDb.CityId = Client.CityId;
            clientFromDb.Mol = Client.Mol;
            clientFromDb.Phone = Client.Phone;
            clientFromDb.Email = Client.Email;
            clientFromDb.Description = Client.Description;

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        
        private async Task LoadCities(int? selectedCityId = null)
        {
            Cities = new SelectList(
                await _context.Cities.ToListAsync(),
                "CityId",
                "CityName",
                selectedCityId
            );
        }
    }
}