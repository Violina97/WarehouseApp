using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages
{
    [Authorize]
    public class SearchModel : PageModel
    {
        private readonly WarehouseContext _context;

        public SearchModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public string Term { get; set; } = "";

        public List<Product> Products { get; set; } = new();

        public List<Client> Clients { get; set; } = new();

        public List<Store> Stores { get; set; } = new();

        public List<InvoiceMaster> Invoices { get; set; } = new();

        public List<OutgoingOrder> Orders { get; set; } = new();

        public void OnGet()
        {
            if (string.IsNullOrWhiteSpace(Term))
                return;

            Products = _context.Products
                .Where(p => p.Name.Contains(Term))
                .Take(10)
                .ToList();

            Clients = _context.Clients
                .Where(c => c.Name.Contains(Term))
                .Take(10)
                .ToList();

            Stores = _context.Stores
                .Where(s => s.Name.Contains(Term))
                .Take(10)
                .ToList();

            if (int.TryParse(Term, out int number))
            {
                Invoices = _context.InvoiceMasters
                    .Include(i => i.Client)
                    .Where(i => i.Number == number)
                    .ToList();

                Orders = _context.OutgoingOrders
                    .Include(o => o.ClientStore)
                    .Where(o => o.Number == number)
                    .ToList();
            }
        }
    }
}