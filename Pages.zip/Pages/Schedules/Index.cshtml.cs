﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Schedules
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public IList<Schedule> Schedules { get; set; } = new List<Schedule>();

        public async Task OnGetAsync()
        {
            Schedules = await _context.Schedules
                .Include(s => s.Worker)
                .Include(s => s.Automobile)
                .Include(s => s.OutgoingOrder)
                .Include(s => s.InvoiceMaster)
                .Include(s => s.ClientStore)
                .OrderByDescending(s => s.DeliveryDate)
                .ToListAsync();
        }
    }
}