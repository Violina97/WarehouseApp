using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Schedules
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateFromInvoiceModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateFromInvoiceModel(WarehouseContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> OnGetAsync(int invoiceMId)
        {
            var invoice = await _context.InvoiceMasters
                .FirstOrDefaultAsync(i => i.InvoiceMId == invoiceMId);

            if (invoice == null)
                return NotFound();

            
            var order = await _context.OutgoingOrders
                .FirstOrDefaultAsync(o =>
                    o.ClientStoreId == invoice.ClientId);

            var schedule = new Schedule
            {
                InvoiceMId = invoice.InvoiceMId,
                OrderMId = order?.Id,   
                WorkerId = invoice.WorkerId,

                DeliveryDate = DateTime.Today.AddDays(1),
                DeliveryHour = new TimeSpan(9, 0, 0),

                Status = "P"
            };

            _context.Schedules.Add(schedule);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Schedules/Index");
        }
    }
}