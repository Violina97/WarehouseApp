﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Schedules
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Schedule Schedule { get; set; } = new Schedule();

        public SelectList OrdersList { get; set; } = default!;
        public SelectList AutomobilesList { get; set; } = default!;
        public SelectList WorkersList { get; set; } = default!;
        public SelectList ClientStoresList { get; set; } = default!;
        public string? InvoiceNumber { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadDataAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDataAsync();

            if (!ModelState.IsValid)
                return Page();

            var order = await _context.OutgoingOrders
                .FirstOrDefaultAsync(o => o.Id == Schedule.OrderMId);

            if (order == null)
            {
                ModelState.AddModelError("", "Невалидна поръчка.");
                return Page();
            }

            var invoice = await _context.InvoiceMasters
                .FirstOrDefaultAsync(i => i.ClientId == order.ClientStoreId);

            Schedule.InvoiceMId = invoice?.InvoiceMId;
            InvoiceNumber = invoice?.Number.ToString();

        
            var conflict = await _context.Schedules.AnyAsync(s =>
                s.DeliveryDate == Schedule.DeliveryDate &&
                s.DeliveryHour == Schedule.DeliveryHour &&
                (s.WorkerId == Schedule.WorkerId ||
                 s.AutomobileId == Schedule.AutomobileId));

            if (conflict)
            {
                ModelState.AddModelError("", "Има конфликт в графика.");
                return Page();
            }

            Schedule.Status = "P";

            _context.Schedules.Add(Schedule);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadDataAsync()
        {
            OrdersList = new SelectList(
                await _context.OutgoingOrders.ToListAsync(),
                "Id",
                "Id"
            );

            AutomobilesList = new SelectList(
                await _context.Automobiles.ToListAsync(),
                "AutoId",
                "Model"
            );

            WorkersList = new SelectList(
                await _context.Workers
                    .Include(w => w.Position)
                    .Where(w => w.Position.PositionName == "Шофьор доставка")
                    .Select(w => new
                    {
                        w.WorkerId,
                        FullName = w.FirstName + " " + w.LastName
                    })
                    .ToListAsync(),
                "WorkerId",
                "FullName"
            );

            ClientStoresList = new SelectList(
                await _context.ClientStores.ToListAsync(),
                "ClientStoreId",
                "Name"
            );
        }
    }
}