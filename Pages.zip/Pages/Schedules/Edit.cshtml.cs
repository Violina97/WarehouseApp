﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Schedules
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Schedule Schedule { get; set; } = default!;

        public SelectList OrdersList { get; set; } = default!;
        public SelectList InvoicesList { get; set; } = default!;
        public SelectList AutomobilesList { get; set; } = default!;
        public SelectList WorkersList { get; set; } = default!;
        public SelectList ClientStoresList { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Schedule = await _context.Schedules
                .Include(s => s.Worker)
                .Include(s => s.Automobile)
                .Include(s => s.ClientStore)
                .Include(s => s.InvoiceMaster)
                .Include(s => s.OutgoingOrder)
                .FirstOrDefaultAsync(s => s.ScheduleId == id);

            if (Schedule == null)
                return NotFound();

            await LoadDataAsync();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadDataAsync();

            if (!ModelState.IsValid)
                return Page();

            var dbSchedule = await _context.Schedules
                .FirstOrDefaultAsync(s => s.ScheduleId == Schedule.ScheduleId);

            if (dbSchedule == null)
                return NotFound();

        
            var conflict = await _context.Schedules.AnyAsync(s =>
                s.ScheduleId != Schedule.ScheduleId &&
                s.DeliveryDate == Schedule.DeliveryDate &&
                s.DeliveryHour == Schedule.DeliveryHour &&
                (
                    s.WorkerId == Schedule.WorkerId ||
                    s.AutomobileId == Schedule.AutomobileId
                )
            );

            if (conflict)
            {
                ModelState.AddModelError(string.Empty,
                    "Има конфликт: шофьорът или автомобилът вече са заети за този час.");

                return Page();
            }

            
            dbSchedule.OrderMId = Schedule.OrderMId;
            dbSchedule.InvoiceMId = Schedule.InvoiceMId;
            dbSchedule.AutomobileId = Schedule.AutomobileId;
            dbSchedule.WorkerId = Schedule.WorkerId;
            dbSchedule.ClientStoreId = Schedule.ClientStoreId;
            dbSchedule.DeliveryDate = Schedule.DeliveryDate;
            dbSchedule.DeliveryHour = Schedule.DeliveryHour;
            dbSchedule.Km = Schedule.Km;
            dbSchedule.Status = Schedule.Status;

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        private async Task LoadDataAsync()
        {
            OrdersList = new SelectList(
                await _context.OutgoingOrders
                    .AsNoTracking()
                    .Select(o => new
                    {
                        o.Id,
                        Display = "Order #" + o.Number
                    })
                    .ToListAsync(),
                "Id",
                "Display"
            );

            InvoicesList = new SelectList(
                await _context.InvoiceMasters
                    .AsNoTracking()
                    .Select(i => new
                    {
                        i.InvoiceMId,
                        Display = "Invoice #" + i.Number
                    })
                    .ToListAsync(),
                "InvoiceMId",
                "Display"
            );

            AutomobilesList = new SelectList(
                await _context.Automobiles
                    .AsNoTracking()
                    .Select(a => new
                    {
                        a.AutoId,
                        Display = a.Model
                    })
                    .ToListAsync(),
                "AutoId",
                "Display"
            );

            
            WorkersList = new SelectList(
                await _context.Workers
                    .AsNoTracking()
                    .Include(w => w.Position)
                    .Where(w => w.Position.PositionName == "Шофьор доставка")
                    .Select(w => new
                    {
                        w.WorkerId,
                        FullName = (w.FirstName ?? "") + " " + (w.LastName ?? "")
                    })
                    .ToListAsync(),
                "WorkerId",
                "FullName"
            );

            ClientStoresList = new SelectList(
                await _context.ClientStores
                    .AsNoTracking()
                    .Select(c => new
                    {
                        c.ClientStoreId,
                        Display = c.Name
                    })
                    .ToListAsync(),
                "ClientStoreId",
                "Display"
            );
        }
    }
}