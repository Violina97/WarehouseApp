﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Schedules
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public Schedule Schedule { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Schedule = await _context.Schedules
                .Include(s => s.Worker)
                .Include(s => s.Automobile)
                .Include(s => s.OutgoingOrder)
                .Include(s => s.InvoiceMaster)
                .Include(s => s.ClientStore)
                .FirstOrDefaultAsync(m => m.ScheduleId == id);

            if (Schedule == null)
                return NotFound();

            return Page();
        }
    }
}