﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.Stores
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Store Store { get; set; }

        public SelectList Cities { get; set; }

        public void OnGet()
        {
            Store = new Store();

            Cities = new SelectList(_context.Cities.ToList(), "CityId", "CityName");
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Cities = new SelectList(_context.Cities.ToList(), "CityId", "CityName");
                return Page();
            }

            _context.Stores.Add(Store);
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }
    }
}