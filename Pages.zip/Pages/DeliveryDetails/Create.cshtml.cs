﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class CreateModel : PageModel
    {
        private readonly WarehouseContext _context;

        public CreateModel(WarehouseContext context)
        {
            _context = context;
        }

        public int DeliveryMId { get; set; }
        [BindProperty]
        public DeliveryDetail DeliveryDetail { get; set; } = new();

        public SelectList Products { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int deliveryMId)
        {
            DeliveryMId = deliveryMId;

            DeliveryDetail.DeliveryMId = deliveryMId;

            LoadData();

            return Page();
        }

        private void LoadData()
        {
            Products = new SelectList(
                _context.Products
                    .AsNoTracking()
                    .Include(x => x.Measure)
                    .OrderBy(x => x.Name)
                    .Select(x => new
                    {
                        x.Id,
                        Text = x.Name + " | " +
                               x.Price.ToString("0.00") + " € | " +
                               x.Measure.MeasureName
                    })
                    .ToList(),
                "Id",
                "Text"
            );
        }

        public async Task<IActionResult> OnPostAsync()
        {
            LoadData();

            if (!ModelState.IsValid)
                return Page();

            var product = await _context.Products
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == DeliveryDetail.ProductId);

            if (product == null)
            {
                ModelState.AddModelError("", "Невалиден продукт.");
                return Page();
            }

            DeliveryDetail.Price = product.Price;

            _context.DeliveryDetails.Add(DeliveryDetail);
            await _context.SaveChangesAsync();

            return RedirectToPage("/DeliveryDetails/Index",
                new { deliveryMId = DeliveryDetail.DeliveryMId });
        }
    }
}