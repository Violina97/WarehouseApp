﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class IndexModel : PageModel
    {
        private readonly WarehouseContext _context;

        public IndexModel(WarehouseContext context)
        {
            _context = context;
        }

        public DeliveryMaster Master { get; set; } = default!;

        public List<DeliveryDetailVm> Items { get; set; } = new();

        public decimal TotalAmount { get; set; }

        public async Task<IActionResult> OnGetAsync(int deliveryMId)
        {
          
            Master = await _context.DeliveryMasters
                .AsNoTracking()
                .Include(x => x.Store)
                .Include(x => x.ClientStore)
                .Include(x => x.Worker)
                .FirstOrDefaultAsync(x => x.DeliveryMId == deliveryMId);

            if (Master == null)
                return NotFound();

            
            Items = await _context.DeliveryDetails
                .AsNoTracking()
                .Where(x => x.DeliveryMId == deliveryMId)
                .Select(x => new DeliveryDetailVm
                {
                    DeliveryDId = x.DeliveryDId,

                    ProductName = x.Product != null
                        ? x.Product.Name
                        : "-",

                    MeasureName = x.Product != null &&
                                  x.Product.Measure != null
                        ? x.Product.Measure.MeasureName
                        : "-",

                    Quantity = x.Quantity,

                    Price = x.Price,

                    RowTotal = x.Quantity * x.Price
                })
                .ToListAsync();

            TotalAmount = Items.Sum(x => x.RowTotal);

            return Page();
        }

        public async Task<IActionResult> OnPostDeleteAsync(
            int id,
            int deliveryMId)
        {
            var item = await _context.DeliveryDetails
                .FirstOrDefaultAsync(x =>
                    x.DeliveryDId == id &&
                    x.DeliveryMId == deliveryMId);

            if (item != null)
            {
                _context.DeliveryDetails.Remove(item);

                await _context.SaveChangesAsync();
            }

            return RedirectToPage(new { deliveryMId });
        }
    }

    public class DeliveryDetailVm
    {
        public int DeliveryDId { get; set; }

        public string ProductName { get; set; } = "";

        public string MeasureName { get; set; } = "";

        public decimal Quantity { get; set; }

        public decimal Price { get; set; }

        public decimal RowTotal { get; set; }
    }
}