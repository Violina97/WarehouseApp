﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class EditModel : PageModel
    {
        private readonly WarehouseContext _context;

        public EditModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public DeliveryDetail DeliveryDetail { get; set; } = new();

        public SelectList Products { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var item = await _context.DeliveryDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.DeliveryDId == id);

            if (item == null)
                return NotFound();

            DeliveryDetail = item;

            LoadProducts();

            return Page();
        }

        private void LoadProducts()
        {
            Products = new SelectList(
                _context.Products
                    .AsNoTracking()
                    .Include(x => x.Measure)
                    .OrderBy(x => x.Name)
                    .Select(x => new
                    {
                        x.Id,
                        Text = x.Name
                               + " | "
                               + x.Price.ToString("0.00 €")
                               + " | "
                               + x.Measure.MeasureName
                    })
                    .ToList(),
                "Id",
                "Text"
            );
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (DeliveryDetail.ProductId <= 0 || DeliveryDetail.Quantity <= 0)
            {
                ModelState.AddModelError("", "Моля изберете валиден артикул и количество.");

                LoadProducts();

                return Page();
            }

            var item = await _context.DeliveryDetails
                .FirstOrDefaultAsync(x =>
                    x.DeliveryDId == DeliveryDetail.DeliveryDId);

            if (item == null)
                return NotFound();

            var product = await _context.Products
                .AsNoTracking()
                .Include(x => x.Measure)
                .FirstOrDefaultAsync(x =>
                    x.Id == DeliveryDetail.ProductId);

            if (product == null)
            {
                ModelState.AddModelError("", "Невалиден продукт.");

                LoadProducts();

                return Page();
            }

      
            item.ProductId = DeliveryDetail.ProductId;
            item.Quantity = DeliveryDetail.Quantity;

           
            item.Price = product.Price;

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index",
                new { deliveryMId = item.DeliveryMId });
        }
    }
}