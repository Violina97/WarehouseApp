﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryDetails
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DeleteModel(WarehouseContext context)
        {
            _context = context;
        }

        [BindProperty]
        public DeliveryDetail DeliveryDetail { get; set; } = default!;

        public Product? Product { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (id <= 0)
                return NotFound();

            DeliveryDetail = await _context.DeliveryDetails
                .AsNoTracking()
                .Include(x => x.Product)
                    .ThenInclude(p => p.Measure)
                .FirstOrDefaultAsync(x => x.DeliveryDId == id);

            if (DeliveryDetail == null)
                return NotFound();

            Product = DeliveryDetail.Product;

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            if (id <= 0)
                return NotFound();

            var item = await _context.DeliveryDetails
                .FirstOrDefaultAsync(x => x.DeliveryDId == id);

            if (item == null)
                return NotFound();

            var deliveryMId = item.DeliveryMId;

            _context.DeliveryDetails.Remove(item);

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index",
                new { deliveryMId });
        }
    }
}