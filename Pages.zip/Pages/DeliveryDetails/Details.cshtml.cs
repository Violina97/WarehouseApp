﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WarehouseApp.Data;
using WarehouseApp.Models;

namespace WarehouseApp.Pages.DeliveryDetails
{
    [Authorize(Roles = "Admin,Employee")]
    public class DetailsModel : PageModel
    {
        private readonly WarehouseContext _context;

        public DetailsModel(WarehouseContext context)
        {
            _context = context;
        }

        public DeliveryDetail DeliveryDetail { get; set; } = default!;

        public Product? Product { get; set; }

        public decimal Total => DeliveryDetail.Quantity * DeliveryDetail.Price;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (id <= 0)
                return NotFound();

            var item = await _context.DeliveryDetails
                .AsNoTracking()
                .Include(x => x.Product)
                    .ThenInclude(p => p.Measure)
                .FirstOrDefaultAsync(x => x.DeliveryDId == id);

            if (item == null)
                return NotFound();

            DeliveryDetail = item;
            Product = item.Product;

            return Page();
        }
    }
}