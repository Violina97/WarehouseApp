﻿using Microsoft.EntityFrameworkCore;
using WarehouseApp.Models;

namespace WarehouseApp.Data
{
    public class WarehouseContext : DbContext
    {
        public WarehouseContext(DbContextOptions<WarehouseContext> options)
            : base(options)
        {
        }

        // ================= MAIN =================
        public DbSet<Product> Products { get; set; }
        public DbSet<Store> Stores { get; set; }
        public DbSet<ClientStore> ClientStores { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Worker> Workers { get; set; }
        public DbSet<ContactPerson> ContactPersons { get; set; }

        // ================= USERS =================
        public DbSet<User> Users { get; set; }

        // ================= AUTOMOBILES =================
        public DbSet<Automobile> Automobiles { get; set; }
        public DbSet<AutomobileBrand> AutomobileBrands { get; set; }

        // ================= INVOICE =================
        public DbSet<InvoiceMaster> InvoiceMasters { get; set; }
        public DbSet<InvoiceDetail> InvoiceDetails { get; set; }

        // ================= ORDERS =================
        public DbSet<OutgoingOrder> OutgoingOrders { get; set; }
        public DbSet<OutgoingOrderDetail> OutgoingOrderDetails { get; set; }

        // ================= DELIVERY =================
        public DbSet<DeliveryMaster> DeliveryMasters { get; set; }
        public DbSet<DeliveryDetail> DeliveryDetails { get; set; }

        // ================= LOOKUP =================
        public DbSet<Measure> Measures { get; set; }
        public DbSet<Position> Positions { get; set; }
        public DbSet<Region> Regions { get; set; }
        public DbSet<Municipality> Municipalities { get; set; }
        public DbSet<City> Cities { get; set; }
        public DbSet<Promotion> Promotions { get; set; }
        public DbSet<Revision> Revisions { get; set; }
        public DbSet<Schedule> Schedules { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ================= STORE =================
            modelBuilder.Entity<Store>(entity =>
            {
                entity.ToTable("Stores");
                entity.HasKey(s => s.Id);

                entity.HasOne(s => s.City)
                      .WithMany(c => c.Stores)
                      .HasForeignKey(s => s.CityId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // ================= CITY =================
            modelBuilder.Entity<City>(entity =>
            {
                entity.ToTable("Cities");
                entity.HasKey(c => c.CityId);
            });

            // ================= PRODUCT =================
            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasOne(p => p.Measure)
                      .WithMany()
                      .HasForeignKey(p => p.MeasureId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // ================= AUTOMOBILE =================
            modelBuilder.Entity<Automobile>(entity =>
            {
                entity.ToTable("Automobiles");
                entity.HasKey(a => a.AutoId);

                entity.HasOne(a => a.Store)
                      .WithMany()
                      .HasForeignKey(a => a.StoreId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // ================= DELIVERY MASTER =================
            modelBuilder.Entity<DeliveryMaster>(entity =>
            {
                entity.ToTable("DeliveryMaster");
                entity.HasKey(d => d.DeliveryMId);

                entity.Property(d => d.Number)
                      .IsRequired();

                entity.HasOne(d => d.Store)
                      .WithMany(s => s.DeliveryMasters)
                      .HasForeignKey(d => d.StoreId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.ClientStore)
                      .WithMany(c => c.DeliveryMasters)
                      .HasForeignKey(d => d.ClientStoreId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.Worker)
                      .WithMany(w => w.DeliveryMasters)
                      .HasForeignKey(d => d.WorkerId)
                      .OnDelete(DeleteBehavior.Restrict);

              
                entity.HasMany(d => d.DeliveryDetails)
                      .WithOne(d => d.DeliveryMaster)
                      .HasForeignKey(d => d.DeliveryMId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // ================= DELIVERY DETAIL =================
            modelBuilder.Entity<DeliveryDetail>(entity =>
            {
                entity.ToTable("DeliveryDetail");
                entity.HasKey(d => d.DeliveryDId);

                entity.Property(d => d.Quantity).IsRequired();
                entity.Property(d => d.Price).IsRequired();

                // Product relation
                entity.HasOne(d => d.Product)
                      .WithMany()
                      .HasForeignKey(d => d.ProductId)
                      .OnDelete(DeleteBehavior.Restrict);

               
                entity.HasOne(d => d.DeliveryMaster)
                      .WithMany(d => d.DeliveryDetails)
                      .HasForeignKey(d => d.DeliveryMId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
            modelBuilder.Entity<OutgoingOrder>(entity =>
            {
                entity.ToTable("OutgoingOrders");

                entity.HasKey(o => o.Id);

                entity.Property(o => o.Number)
                    .IsRequired(false);

                entity.Property(o => o.Date)
                    .IsRequired();

                // =========================
                // STORE 
                // =========================
                entity.HasOne(o => o.Store)
                    .WithMany()
                    .HasForeignKey(o => o.StoreId)
                    .OnDelete(DeleteBehavior.Restrict);

                // =========================
                // CLIENT STORE 
                // =========================
                entity.HasOne(o => o.ClientStore)
                    .WithMany()
                    .HasForeignKey(o => o.ClientStoreId)
                    .OnDelete(DeleteBehavior.Restrict);

            });
            modelBuilder.Entity<OutgoingOrderDetail>(entity =>
            {
                entity.ToTable("OutgoingOrderDetails");

                entity.HasKey(d => d.Id);

                // =========================
                // MASTER RELATION
                // =========================
                entity.HasOne(d => d.OutgoingOrder)
                    .WithMany(o => o.OutgoingOrderDetails)
                    .HasForeignKey(d => d.OutgoingOrderId)
                    .OnDelete(DeleteBehavior.Cascade);

                // =========================
                // PRODUCT RELATION
                // =========================
                entity.HasOne(d => d.Product)
                    .WithMany()
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.Restrict);

                // =========================
                // REQUIRED FIELD
                // =========================
                entity.Property(d => d.Quantity)
                    .IsRequired();

               
            });
            modelBuilder.Entity<InvoiceMaster>(entity =>
            {
                entity.ToTable("InvoiceMasters");

                entity.HasKey(i => i.InvoiceMId);

                entity.Property(i => i.Number)
                      .IsRequired();

                entity.Property(i => i.InvoiceDate)
                      .IsRequired();

                // Worker
                entity.HasOne(i => i.Worker)
                      .WithMany(w => w.InvoiceMasters)
                      .HasForeignKey(i => i.WorkerId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Client
                entity.HasOne(i => i.Client)
                      .WithMany(c => c.InvoiceMasters)
                      .HasForeignKey(i => i.ClientId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Details (1 -> many)
                entity.HasMany(i => i.InvoiceDetails)
                      .WithOne(d => d.InvoiceMaster)
                      .HasForeignKey(d => d.InvoiceMId)
                      .OnDelete(DeleteBehavior.Cascade);

            });
            
            modelBuilder.Entity<InvoiceDetail>(entity =>
            {
                entity.ToTable("InvoiceDetails");

                entity.HasKey(d => d.InvoiceDId);

                entity.Property(d => d.Quantity)
                      .IsRequired();

                entity.Property(d => d.Price)
                      .IsRequired();

                // Product
                entity.HasOne(d => d.Product)
                      .WithMany()
                      .HasForeignKey(d => d.ProductId)
                      .OnDelete(DeleteBehavior.Restrict);

                // Parent invoice
                entity.HasOne(d => d.InvoiceMaster)
                      .WithMany(i => i.InvoiceDetails)
                      .HasForeignKey(d => d.InvoiceMId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
            // ================= PROMOTION =================
            modelBuilder.Entity<Promotion>(entity =>
            {
                entity.HasKey(p => p.PromotionId);

                entity.Property(p => p.Discount)
                      .HasColumnType("decimal(5,2)");

                entity.HasOne(p => p.Product)
                      .WithMany()
                      .HasForeignKey(p => p.ProductId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(p => p.Store)
                      .WithMany()
                      .HasForeignKey(p => p.StoreId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
            // ================= Schedule =================

            modelBuilder.Entity<Schedule>(entity =>
            {
                entity.HasKey(s => s.ScheduleId);

                entity.Property(s => s.Status)
                      .HasColumnType("char(1)");

                entity.HasOne(s => s.InvoiceMaster)
                      .WithMany()
                      .HasForeignKey(s => s.InvoiceMId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(s => s.OutgoingOrder)
                      .WithMany()
                      .HasForeignKey(s => s.OrderMId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(s => s.Automobile)
                      .WithMany()
                      .HasForeignKey(s => s.AutomobileId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(s => s.Worker)
                      .WithMany()
                      .HasForeignKey(s => s.WorkerId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(s => s.ClientStore)
                      .WithMany()
                      .HasForeignKey(s => s.ClientStoreId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
            // ================= Revision =================
            modelBuilder.Entity<Revision>(entity =>
            {
                entity.HasKey(r => r.RevisionId);

                entity.HasOne(r => r.Store)
                      .WithMany()
                      .HasForeignKey(r => r.StoreId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(r => r.Product)
                      .WithMany()
                      .HasForeignKey(r => r.ProductId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(r => r.Worker)
                      .WithMany()
                      .HasForeignKey(r => r.WorkerId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
            // ================= USER =================
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");

                entity.HasKey(u => u.Id);

                entity.HasOne(u => u.Worker)
                      .WithMany()
                      .HasForeignKey(u => u.WorkerId)
                      .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}