﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WarehouseApp.ModelBinders;

namespace WarehouseApp.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Име на продукта")]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Описание")]
        [MaxLength(255)]
        public string? Description { get; set; }

        [Required]
        [Display(Name = "Цена")]
        [Range(0.01, 999999)]
        [ModelBinder(BinderType = typeof(DecimalModelBinder))]
        public decimal Price { get; set; }

        
        [Display(Name = "Мерна единица")]
        public int MeasureId { get; set; }

        public Measure? Measure { get; set; }

        
        [Display(Name = "Количество за отстъпка")]
        [Range(0, 999999)]
        public decimal DiscountQuantity { get; set; }

        
        [Display(Name = "Процент отстъпка")]
        [Range(0, 100)]
        public decimal DiscountPercent { get; set; }

        
    }
}