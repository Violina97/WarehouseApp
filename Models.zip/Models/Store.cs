﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WarehouseApp.Models
{
    public class Store
    {
        public int Id { get; set; }

        [Required]
        [StringLength(30)]
        public string Name { get; set; }

        [Display(Name = "Град")]
        public int CityId { get; set; }

        [Required]
        [StringLength(50)]
        public string Address { get; set; }

        [StringLength(100)]
        public string Description { get; set; }

        public City City { get; set; }
        public ICollection<DeliveryMaster> DeliveryMasters { get; set; }
    = new List<DeliveryMaster>();
    }
}