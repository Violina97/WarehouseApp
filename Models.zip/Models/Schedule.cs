﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WarehouseApp.Models
{
    public class Schedule
    {
        [Key]
        public int ScheduleId { get; set; }
        public int? InvoiceMId { get; set; }
        public InvoiceMaster? InvoiceMaster { get; set; }

        public int? OrderMId { get; set; }
        public OutgoingOrder? OutgoingOrder { get; set; }

        public int? AutomobileId { get; set; }
        public Automobile? Automobile { get; set; }

       
        public int? WorkerId { get; set; }
        public Worker? Worker { get; set; }

       
        public int? ClientStoreId { get; set; }
        public ClientStore? ClientStore { get; set; }

        public decimal Km { get; set; }

        public DateTime? DeliveryDate { get; set; }

        public TimeSpan? DeliveryHour { get; set; }

        // Статус (P, I, D, C)
        public string Status { get; set; } = "P";

      
        [NotMapped]
        public string StatusText => Status switch
        {
            "P" => "Планиран",
            "I" => "В изпълнение",
            "D" => "Завършен",
            "C" => "Отказан",
            _ => "Неизвестен"
        };

        [NotMapped]
        public bool IsCompleted => Status == "D";

        [NotMapped]
        public bool IsActive => Status == "P" || Status == "I";
    }
}