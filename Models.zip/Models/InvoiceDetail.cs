﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WarehouseApp.Models
{
    public class InvoiceDetail
    {
        [Key]
        public int InvoiceDId { get; set; }

        public int ProductId { get; set; }

        [Range(0.01, double.MaxValue)]
        public decimal Quantity { get; set; }

        public decimal Price { get; set; }

        public int InvoiceMId { get; set; }


        public Product? Product { get; set; }

        public InvoiceMaster? InvoiceMaster { get; set; }

       
        [NotMapped]
        public decimal Total => Quantity * Price;

        
        [NotMapped]
        public string? ProductName { get; set; }
    }
}