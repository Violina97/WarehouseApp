﻿namespace WarehouseApp.Models
{
    public class Region
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public ICollection<Municipality> Municipalities { get; set; }
            = new List<Municipality>();
    }
}



