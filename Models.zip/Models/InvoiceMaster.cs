﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WarehouseApp.Models
{
    public class InvoiceMaster
    {
        [Key]
        public int InvoiceMId { get; set; }

        [Required]
        [Display(Name = "Служител")]
        public int WorkerId { get; set; }

        [Required]
        [Display(Name = "Клиент")]
        public int ClientId { get; set; }


        [Required]
        [Display(Name = "Номер")]
        public int Number { get; set; }

        [Required]
        [Display(Name = "Дата на издаване")]
        public DateTime InvoiceDate { get; set; }

        [StringLength(100)]
        [Display(Name = "Приел")]
        public string? Receiver { get; set; }

        public Client? Client { get; set; }

        public Worker? Worker { get; set; }
        public ICollection<InvoiceDetail> InvoiceDetails { get; set; }
            = new List<InvoiceDetail>();

       
        [NotMapped]
        public decimal Total => InvoiceDetails?.Sum(d => d.Total) ?? 0;
    }
}