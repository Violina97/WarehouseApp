﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace WarehouseApp.Models
{
    
    public class DeliveryMaster
    {
        public int DeliveryMId { get; set; }
        public int StoreId { get; set; }
        public Store? Store { get; set; }

        public int Number { get; set; }
        public int ClientStoreId { get; set; }
        public ClientStore? ClientStore { get; set; }
        public int WorkerId { get; set; }
        public Worker? Worker { get; set; }

        public DateTime DeliveryDate { get; set; }

        public ICollection<DeliveryDetail> DeliveryDetails { get; set; }
            = new List<DeliveryDetail>();

        
        [NotMapped]
        public decimal TotalAmount =>
            DeliveryDetails?.Sum(x => x.Quantity * x.Price) ?? 0;
    }
}