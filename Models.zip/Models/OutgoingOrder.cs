﻿namespace WarehouseApp.Models
{
    public class OutgoingOrder
    {
        public int Id { get; set; }

        public int? Number { get; set; }

        public DateTime Date { get; set; }

        public int StoreId { get; set; }
        public Store? Store { get; set; }

        public int ClientStoreId { get; set; }
        public ClientStore? ClientStore { get; set; }

        public ICollection<OutgoingOrderDetail> OutgoingOrderDetails { get; set; }
            = new List<OutgoingOrderDetail>();
      
    }
}