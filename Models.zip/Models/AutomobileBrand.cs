﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class AutomobileBrand
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(30)]
        public string BrandName { get; set; } = string.Empty;

        
        public ICollection<Automobile> Automobiles { get; set; }
            = new List<Automobile>();
    }
}