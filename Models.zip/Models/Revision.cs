﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class Revision
    {
        [Key]
        public int RevisionId { get; set; }

        public int? StoreId { get; set; }
       
        public DateTime? RevisionDate { get; set; }

        public int? ProductId { get; set; }

        public decimal Quantity { get; set; }

        public int? WorkerId { get; set; }

        
        public Store? Store { get; set; }

        public Product? Product { get; set; }

        public Worker? Worker { get; set; }
    }
}