﻿namespace WarehouseApp.Models
{
    public class Municipality
    {
        public int Id { get; set; }

        public int MunicipNr { get; set; }

        public string MunicipName { get; set; } = string.Empty;

        public int RegionId { get; set; }

        public Region? Region { get; set; }

        public ICollection<City> Cities { get; set; }
            = new List<City>();
    }
}