﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class Promotion
    {
        [Key]
        public int PromotionId { get; set; }
        public int? StoreId { get; set; }
        public int? ProductId { get; set; }

        [Required]
        [Range(0, 100)]
        public decimal Discount { get; set; }

        [Required]
        public DateTime Validity { get; set; }

        public Store? Store { get; set; }
        public Product? Product { get; set; }
    }
}