﻿namespace WarehouseApp.Models
{
    public class OutgoingOrderDetail
    {
        public int Id { get; set; }

        public int OutgoingOrderId { get; set; }
        public OutgoingOrder? OutgoingOrder { get; set; }

        public int ProductId { get; set; }
        public Product? Product { get; set; }

        public decimal Quantity { get; set; }

    }
}