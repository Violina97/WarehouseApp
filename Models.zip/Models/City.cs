﻿namespace WarehouseApp.Models
{
    public class City
    {
        public int CityId { get; set; }

        public string Ekatte { get; set; } = string.Empty;

        public string CityName { get; set; } = string.Empty;

        
        public int MunicipalityId { get; set; }

        public Municipality? Municipality { get; set; }

        public ICollection<Store> Stores { get; set; }
            = new List<Store>();
    }
}