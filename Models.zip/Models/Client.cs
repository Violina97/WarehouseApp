﻿using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class Client
    {
        public int ClientId { get; set; }

        [Required]
        [MaxLength(100)]
        [Display(Name = "Име на клиент")]
        public string Name { get; set; } = string.Empty;

        [MaxLength(20)]
        [Display(Name = "Булстат")]
        public string? Bulstat { get; set; }

        [MaxLength(20)]
        [Display(Name = "Регистрационен номер")]
        public string? RegistryNumber { get; set; }

        [MaxLength(255)]
        [Display(Name = "Адрес")]
        public string? Address { get; set; }

        [Display(Name = "Град")]
        public int? CityId { get; set; }

        public City? City { get; set; }

        [MaxLength(100)]
        [Display(Name = "МОЛ")]
        public string? Mol { get; set; }

        [MaxLength(20)]
        [Display(Name = "Телефон")]
        public string? Phone { get; set; }

        [MaxLength(100)]
        [EmailAddress]
        [Display(Name = "Имейл")]
        public string? Email { get; set; }

        [MaxLength(255)]
        [Display(Name = "Описание")]
        public string? Description { get; set; }

       
        [Display(Name = "Дата на създаване")]
        public DateTime CreatedAt { get; set; }

        public ICollection<InvoiceMaster> InvoiceMasters { get; set; }
    = new List<InvoiceMaster>();
    }
}