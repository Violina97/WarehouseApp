﻿namespace WarehouseApp.Models
{
    
    public class DeliveryDetail
    {
        
        public int DeliveryDId { get; set; }
        public int DeliveryMId { get; set; }
        public DeliveryMaster? DeliveryMaster { get; set; }
        public int ProductId { get; set; }
        public Product? Product { get; set; }

        public decimal Quantity { get; set; }
        public decimal Price { get; set; }
    }
}