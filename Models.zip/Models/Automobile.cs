﻿using WarehouseApp.Models;

public class Automobile
{
    public int AutoId { get; set; }

    public decimal? LoadValue { get; set; }

    public int? AutomobileBrandId { get; set; }
    public AutomobileBrand? AutomobileBrand { get; set; }

    public string? Model { get; set; }
    public string? Description { get; set; }

    public int? WorkerId { get; set; }
    public Worker? Worker { get; set; }

    public int? StoreId { get; set; }
    public Store? Store { get; set; }

    public string? RegisterNr { get; set; }
}