﻿namespace WarehouseApp.Models
{
    public class Measure
    {
        public int MeasureId { get; set; }

        public string MeasureName { get; set; } = string.Empty;

        public string? Description { get; set; }
    }
}
