﻿using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class ContactPerson
    {
        public int ContactPersonId { get; set; }

        [Required, MaxLength(20)]
        public string FirstName { get; set; } = string.Empty;

        [Required, MaxLength(20)]
        public string LastName { get; set; } = string.Empty;

        public int PositionId { get; set; }
        public Position? Position { get; set; }

        [MaxLength(15)]
        public string? Telephone { get; set; }

        [MaxLength(40)]
        public string? Mail { get; set; }

        public int ClientId { get; set; }
        public Client? Client { get; set; }
    }
}