﻿using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class Position
    {
        public int PositionId { get; set; }
        [Required]
        public string PositionName { get; set; } = string.Empty;

        public ICollection<Worker> Workers { get; set; } = new List<Worker>();
    }
}