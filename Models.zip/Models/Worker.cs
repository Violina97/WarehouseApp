﻿namespace WarehouseApp.Models
{
    public class Worker
    {
        public int WorkerId { get; set; }

        public string FirstName { get; set; } = string.Empty;
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;

        public string FullName => $"{FirstName ?? ""} {LastName ?? ""}".Trim();

        public string EGN { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Telephone { get; set; } = string.Empty;
        public int StoreId { get; set; }
        public int PositionId { get; set; }
    
        public Store? Store { get; set; }
        public Position? Position { get; set; }

        public ICollection<DeliveryMaster> DeliveryMasters { get; set; }
       = new List<DeliveryMaster>();
        public ICollection<InvoiceMaster> InvoiceMasters { get; set; }
    = new List<InvoiceMaster>();
    }
}