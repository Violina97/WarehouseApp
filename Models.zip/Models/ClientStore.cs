﻿using System.ComponentModel.DataAnnotations;

namespace WarehouseApp.Models
{
    public class ClientStore
    {
        public int ClientStoreId { get; set; }

        [Required]
        [MaxLength(30)]
        public string Name { get; set; } = string.Empty;

        public int? CityId { get; set; }

        [MaxLength(50)]
        public string? Address { get; set; }

        [MaxLength(50)]
        public string? Description { get; set; }

        public int? ClientId { get; set; }

        public City City { get; set; }

        public Client Client { get; set; }

        public ICollection<DeliveryMaster> DeliveryMasters { get; set; }
        = new List<DeliveryMaster>();
    }
}
